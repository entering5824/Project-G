"""Two-level native navigation, retaining QListWidget keyboard behavior."""
from PySide6.QtCore import QRect, QSize, Qt
from PySide6.QtGui import QColor, QFont
from PySide6.QtWidgets import QStyledItemDelegate, QStyle

from .theme import COLORS


class NavigationDelegate(QStyledItemDelegate):
    descriptions = ("Việc nên làm hôm nay", "Các mốc nâng cấp", "Trang bị và build", "Xếp hạng và ưu tiên")

    def sizeHint(self, option, index):
        return QSize(140, 68 if option.rect.width() >= 180 else 48)

    def paint(self, painter, option, index):
        painter.save()
        rect = option.rect.adjusted(0, 3, 0, -3)
        selected = bool(option.state & QStyle.StateFlag.State_Selected)
        hovered = bool(option.state & QStyle.StateFlag.State_MouseOver)
        if selected or hovered:
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QColor(COLORS["elevated"] if selected else COLORS["hover"]))
            painter.drawRoundedRect(rect, 8, 8)
        if selected:
            painter.fillRect(QRect(rect.left(), rect.top() + 12, 3, rect.height() - 24), QColor(COLORS["accent"]))
        font = QFont(option.font)
        font.setPixelSize(14)
        font.setWeight(QFont.Weight.DemiBold)
        painter.setFont(font)
        painter.setPen(QColor(COLORS["accent_hover"] if selected else COLORS["text"]))
        wide = rect.width() >= 180
        title_rect = rect.adjusted(15, 9 if wide else 0, -42, -25 if wide else 0)
        painter.drawText(title_rect, Qt.AlignmentFlag.AlignVCenter, index.data())
        font.setPixelSize(11)
        font.setWeight(QFont.Weight.Normal)
        painter.setFont(font)
        painter.setPen(QColor(COLORS["secondary"]))
        painter.drawText(rect.adjusted(0, 0, -12, 0), Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter, f"^{index.row() + 1}")
        if wide:
            painter.drawText(rect.adjusted(15, 32, -10, -6), Qt.AlignmentFlag.AlignVCenter, self.descriptions[index.row()])
        if option.state & QStyle.StateFlag.State_HasFocus:
            painter.setPen(QColor(COLORS["accent"]))
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.drawRoundedRect(rect.adjusted(1, 1, -1, -1), 8, 8)
        painter.restore()
