"""First native desktop cut: three read-only destinations on direct services."""

import logging
import json
import re
import sys
from datetime import datetime
from pathlib import Path
from uuid import uuid4

from PySide6.QtCore import QObject, QRunnable, QThreadPool, QTimer, Qt, Signal, QUrl
from PySide6.QtGui import (
    QDesktopServices, QPixmap, QIcon, QPainter, QColor, QFont, QBrush, QPen, QShortcut, QKeySequence, QPalette
)
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QDialog, QDialogButtonBox, QDoubleSpinBox, QFileDialog,
    QFormLayout, QFrame, QHBoxLayout, QLabel, QLineEdit, QListWidget, QListWidgetItem, QMainWindow, QMenu,
    QInputDialog,
    QMessageBox, QPushButton, QSpinBox, QSplitter, QStackedWidget, QTabWidget, QTextEdit,
    QAbstractItemView, QHeaderView,
    QTableWidget, QTableWidgetItem, QTreeWidget, QTreeWidgetItem, QVBoxLayout, QWidget,
    QScrollArea, QProgressBar, QToolButton, QStyle,
)

from projectg.interface_adapters.controllers.desktop_reference_controller import (
    label_for,
    target_contract_bundle,
    parse_snapshot,
)

from projectg.presentation.desktop.pyside6.theme import COLORS, DESKTOP_STYLE, set_state
from projectg.presentation.desktop.pyside6.responsive_grid import ResponsiveCardGrid
from projectg.presentation.desktop.pyside6.navigation import NavigationDelegate
from projectg.presentation.desktop.pyside6.row_details_dialog import RowDetailsDialog
from projectg.presentation.desktop.result_export import export_results

log = logging.getLogger(__name__)


def _find_asset_dir() -> Path | None:
    # 1. Check relative to this source file (workspace_root/assets/genshin-impact)
    base = Path(__file__).resolve().parents[5] / "assets" / "genshin-impact"
    if base.is_dir():
        return base
    # 2. Check current working directory
    base = Path.cwd() / "assets" / "genshin-impact"
    if base.is_dir():
        return base
    # 3. Check PyInstaller bundle
    if hasattr(sys, "_MEIPASS"):
        base = Path(sys._MEIPASS) / "assets" / "genshin-impact"
        if base.is_dir():
            return base
    return None


ASSET_DIR = _find_asset_dir()


def _slugify_key(key: str) -> str:
    s = re.sub(r'([a-z0-9])([A-Z])', r'\1-\2', str(key or ''))
    s = re.sub(r'[\s_]+', '-', s)
    return s.strip('-').lower()


def get_character_pixmap(character_key: str, size: int = 64) -> QPixmap:
    if ASSET_DIR and character_key:
        chars_dir = ASSET_DIR / "characters"
        slug = _slugify_key(character_key)
        candidates = [
            chars_dir / f"{slug}.webp",
            chars_dir / f"{character_key.lower()}.webp",
            chars_dir / f"{slug.replace('-', '')}.webp",
        ]
        for p in candidates:
            if p.is_file():
                pix = QPixmap(str(p))
                if not pix.isNull():
                    return pix.scaled(size, size, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)

    # Fallback monogram with celestial styling
    pix = QPixmap(size, size)
    pix.fill(Qt.GlobalColor.transparent)
    painter = QPainter(pix)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    painter.setBrush(QBrush(QColor(COLORS["elevated"])))
    painter.setPen(QPen(QColor(COLORS["accent"]), 1.5))
    painter.drawRoundedRect(1, 1, size - 2, size - 2, 8, 8)
    initials = (character_key[:2] if len(character_key) >= 2 else (character_key or "?")).upper()
    font = QFont("Segoe UI", max(8, int(size * 0.35)), QFont.Weight.Bold)
    painter.setFont(font)
    painter.setPen(QColor(COLORS["accent_hover"]))
    painter.drawText(pix.rect(), Qt.AlignmentFlag.AlignCenter, initials)
    painter.end()
    return pix


def get_weapon_pixmap(weapon_key: str, size: int = 48) -> QPixmap:
    if ASSET_DIR and weapon_key:
        weapons_dir = ASSET_DIR / "weapons"
        slug = _slugify_key(weapon_key)
        candidates = [
            weapons_dir / f"{slug}.webp",
            weapons_dir / f"{weapon_key.lower()}.webp",
            weapons_dir / f"{slug.replace('-', '')}.webp",
        ]
        for p in candidates:
            if p.is_file():
                pix = QPixmap(str(p))
                if not pix.isNull():
                    return pix.scaled(size, size, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)

    pix = QPixmap(size, size)
    pix.fill(Qt.GlobalColor.transparent)
    painter = QPainter(pix)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    painter.setBrush(QBrush(QColor(COLORS["surface"])))
    painter.setPen(QPen(QColor(COLORS["secondary"]), 1))
    painter.drawRoundedRect(1, 1, size - 2, size - 2, 6, 6)
    painter.setPen(QColor(COLORS["secondary"]))
    font = QFont("Segoe UI", max(8, int(size * 0.35)), QFont.Weight.Bold)
    painter.setFont(font)
    painter.drawText(pix.rect(), Qt.AlignmentFlag.AlignCenter, "?")
    painter.end()
    return pix


def _scrollable_form(form):
    """Keep long native forms usable when window height or DPI changes."""
    form.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)
    container = QWidget()
    container.setLayout(form)
    scroll = QScrollArea()
    scroll.setWidgetResizable(True)
    scroll.setFrameShape(QFrame.Shape.NoFrame)
    scroll.setWidget(container)
    scroll.setMinimumHeight(150)
    return scroll


class WorkerSignals(QObject):
    loaded = Signal(int, object)
    failed = Signal(int, str)


class TargetContractDialog(QDialog):
    """One stop prompt, paste, JSON-file, and preview handoff for target imports."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Target JSON · ChatGPT Web")
        self.resize(1000, 700)
        bundle = target_contract_bundle()
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel(
            "Copy prompt sang ChatGPT, dán JSON trả về hoặc mở file, rồi Preview để rà từng target. "
            "Chỉ các dòng được chọn mới được commit; target bỏ chọn sẽ giữ nguyên."))
        self.prompt_view = QTextEdit(); self.prompt_view.setReadOnly(True)
        self.prompt_view.setPlainText(bundle["prompt"])
        self.json_view = QTextEdit()
        self.json_view.setPlaceholderText('Dán JSON trả về, ví dụ {"version":1,"targets":{...}}')
        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.addWidget(self.prompt_view); splitter.addWidget(self.json_view)
        splitter.setStretchFactor(0, 1); splitter.setStretchFactor(1, 1)
        layout.addWidget(splitter, 1)
        actions = QHBoxLayout()
        copy_prompt = QPushButton("Copy prompt")
        copy_prompt.clicked.connect(lambda: QApplication.clipboard().setText(bundle["prompt"]))
        copy_schema = QPushButton("Copy JSON Schema")
        copy_schema.clicked.connect(lambda: QApplication.clipboard().setText(
            json.dumps(bundle["schema"], ensure_ascii=False, indent=2)))
        copy_example = QPushButton("Copy ví dụ")
        copy_example.clicked.connect(lambda: QApplication.clipboard().setText(
            json.dumps(bundle["example"], ensure_ascii=False, indent=2)))
        paste_json = QPushButton("Dán clipboard")
        paste_json.clicked.connect(lambda: self.json_view.setPlainText(QApplication.clipboard().text()))
        open_file = QPushButton("Mở file JSON…")
        open_file.clicked.connect(self._open_json_file)
        actions.addWidget(copy_prompt); actions.addWidget(copy_schema); actions.addWidget(copy_example)
        actions.addWidget(paste_json); actions.addWidget(open_file)
        actions.addStretch(); layout.addLayout(actions)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok |
                                   QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText("Preview targets")
        buttons.accepted.connect(self.accept); buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _open_json_file(self):
        path, _ = QFileDialog.getOpenFileName(self, "Mở Target JSON", "", "JSON (*.json);;All files (*)")
        if not path:
            return
        try:
            file = Path(path)
            if file.stat().st_size > 10 * 1024 * 1024:
                raise ValueError("Target JSON vượt quá 10 MiB.")
            self.json_view.setPlainText(file.read_text(encoding="utf-8-sig"))
        except (OSError, UnicodeError, ValueError) as exc:
            QMessageBox.warning(self, "Target JSON", str(exc))

    def payload(self) -> object:
        raw = self.json_view.toPlainText()
        if len(raw.encode("utf-8")) > 10 * 1024 * 1024:
            raise ValueError("Target JSON vượt quá 10 MiB.")
        return json.loads(raw)


class OverviewWorker(QRunnable):
    def __init__(self, generation: int, controller):
        super().__init__()
        self.generation = generation
        self.controller = controller
        self.signals = WorkerSignals()

    def run(self):
        try:
            self.signals.loaded.emit(self.generation, self.controller.load())
        except Exception as exc:
            log.exception("Desktop overview calculation failed")
            self.signals.failed.emit(self.generation, str(exc))


class GoodWorker(QRunnable):
    def __init__(self, generation: int, path: str, controller, commit: bool, allow_regression: bool = False):
        super().__init__()
        self.generation = generation
        self.path = path
        self.controller = controller
        self.commit = commit
        self.allow_regression = allow_regression
        self.signals = WorkerSignals()

    def run(self):
        try:
            result = (self.controller.commit_good_file(self.path, allow_regression=self.allow_regression)
                      if self.commit else self.controller.preview_good_file(self.path))
            self.signals.loaded.emit(self.generation, result)
        except Exception as exc:
            log.exception("GOOD %s failed", "commit" if self.commit else "preview")
            self.signals.failed.emit(self.generation, str(exc))


class SnapshotWorker(QRunnable):
    def __init__(self, generation: int, payload: object, controller, *, commit: bool = False,
                 allow_regression: bool = False):
        super().__init__()
        self.generation, self.payload, self.commit = generation, payload, commit
        self.controller = controller
        self.allow_regression = allow_regression
        self.signals = WorkerSignals()

    def run(self):
        try:
            result = (self.controller.commit_snapshot(self.payload, allow_regression=self.allow_regression)
                      if self.commit else self.controller.preview_snapshot(self.payload))
            self.signals.loaded.emit(self.generation, result)
        except Exception as exc:
            log.exception("AccountSnapshot %s failed", "commit" if self.commit else "preview")
            self.signals.failed.emit(self.generation, str(exc))


class SnapshotEditorDialog(QDialog):
    """Manual editor and file import for the versioned AccountSnapshot contract."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Account Snapshot · nhập trạng thái hiện tại")
        self.resize(900, 680)
        layout = QVBoxLayout(self)
        tabs = QTabWidget()
        self.tabs = tabs
        json_tab = QWidget(); json_layout = QVBoxLayout(json_tab)
        json_layout.addWidget(QLabel("Dán AccountSnapshot JSON hoặc mở file. activeSets sẽ được tính lại từ các slot."))
        self.editor = QTextEdit()
        self.editor.setPlaceholderText('{"version":1,"characters":{"Mavuika":{"level":90,"ascension":6,"constellation":0,"weapon":{"key":"A Thousand Blazing Suns","level":90},"talents":{"normal":6,"skill":9,"burst":9},"artifacts":{},"activeSets":[]}}}')
        json_layout.addWidget(self.editor, 1)
        row = QHBoxLayout()
        open_file = QPushButton("Mở Snapshot JSON…")
        open_file.clicked.connect(self.open_file)
        paste = QPushButton("Dán clipboard")
        paste.clicked.connect(lambda: self.editor.setPlainText(QApplication.clipboard().text()))
        row.addWidget(open_file); row.addWidget(paste); row.addStretch()
        json_layout.addLayout(row)
        tabs.addTab(json_tab, "JSON")
        form_tab = QWidget(); form_layout = QVBoxLayout(form_tab)
        form = QFormLayout()
        self.manual_key = QLineEdit(); self.manual_level = QSpinBox(); self.manual_level.setRange(1, 100); self.manual_level.setValue(90)
        self.manual_ascension = QSpinBox(); self.manual_ascension.setRange(0, 6); self.manual_ascension.setValue(6)
        self.manual_constellation = QSpinBox(); self.manual_constellation.setRange(0, 6)
        self.manual_weapon = QLineEdit(); self.manual_weapon_level = QSpinBox(); self.manual_weapon_level.setRange(1, 90); self.manual_weapon_level.setValue(90)
        self.manual_weapon_ascension = QSpinBox(); self.manual_weapon_ascension.setRange(0, 6); self.manual_weapon_ascension.setValue(6)
        form.addRow("Character key", self.manual_key); form.addRow("Level", self.manual_level)
        form.addRow("Ascension", self.manual_ascension); form.addRow("Constellation", self.manual_constellation)
        weapon_row = QHBoxLayout(); weapon_row.addWidget(self.manual_weapon); weapon_row.addWidget(self.manual_weapon_level)
        form.addRow("Equipped weapon / level", weapon_row)
        form.addRow("Weapon ascension", self.manual_weapon_ascension)
        self.manual_talents = {}
        talent_row = QHBoxLayout()
        for name in ("normal", "skill", "burst"):
            spin = QSpinBox(); spin.setRange(1, 15); spin.setValue(1)
            self.manual_talents[name] = spin; talent_row.addWidget(QLabel(name.title())); talent_row.addWidget(spin)
        form.addRow("Talents", talent_row)
        self.manual_artifacts = {}
        for slot in ("flower", "plume", "sands", "goblet", "circlet"):
            set_key = QLineEdit(); set_key.setPlaceholderText("Set key (empty = slot absent)")
            main_stat = QLineEdit(); main_stat.setPlaceholderText("Main stat (Sands/Goblet/Circlet)")
            known = QCheckBox("RV known"); rv = QDoubleSpinBox(); rv.setRange(0, 5000); rv.setDecimals(1); rv.setEnabled(False)
            level = QSpinBox(); level.setRange(0, 20); level.setValue(20)
            known.toggled.connect(rv.setEnabled)
            slot_row = QHBoxLayout(); slot_row.addWidget(set_key)
            if slot in {"sands", "goblet", "circlet"}:
                slot_row.addWidget(main_stat)
            slot_row.addWidget(QLabel("Lv")); slot_row.addWidget(level)
            slot_row.addWidget(known); slot_row.addWidget(rv)
            form.addRow(slot.title(), slot_row)
            self.manual_artifacts[slot] = (set_key, main_stat, known, rv, level)
        form_layout.addWidget(_scrollable_form(form), 1)
        add_manual = QPushButton("Thêm / cập nhật nhân vật trong snapshot")
        add_manual.clicked.connect(self._append_manual_character)
        form_layout.addWidget(add_manual); form_layout.addStretch()
        tabs.addTab(form_tab, "Nhập thủ công")
        layout.addWidget(tabs, 1)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText("Phân tích snapshot")
        buttons.accepted.connect(self._validate_and_accept); buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def open_file(self):
        path, _ = QFileDialog.getOpenFileName(self, "Mở Account Snapshot", "", "JSON (*.json);;All files (*)")
        if path:
            try:
                if Path(path).stat().st_size > 25 * 1024 * 1024:
                    raise ValueError("Snapshot JSON vượt quá 25 MiB.")
                self.editor.setPlainText(Path(path).read_text(encoding="utf-8-sig"))
            except (OSError, UnicodeError, ValueError) as exc:
                QMessageBox.warning(self, "Account Snapshot", str(exc))

    def payload(self):
        return json.loads(self.editor.toPlainText())

    def _validate_and_accept(self):
        try:
            payload = self.payload()
            parse_snapshot(payload)
        except Exception as exc:
            QMessageBox.warning(self, "Account Snapshot", str(exc))
            return
        self.accept()

    def _append_manual_character(self):
        key = self.manual_key.text().strip()
        if not key:
            QMessageBox.warning(self, "Account Snapshot", "Nhập canonical character key trước.")
            return
        try:
            payload = self.payload() if self.editor.toPlainText().strip() else {"version": 1, "characters": {}}
            if not isinstance(payload, dict) or payload.get("version") != 1 or not isinstance(payload.get("characters"), dict):
                raise ValueError("JSON hiện tại không phải AccountSnapshot v1.")
            weapon_key = self.manual_weapon.text().strip()
            artifacts = {}
            for slot, (set_box, main_stat, known, rv, level) in self.manual_artifacts.items():
                set_key = set_box.text().strip()
                if set_key:
                    artifacts[slot] = {"setKey": set_key, "rv": rv.value() if known.isChecked() else None,
                                       "level": level.value(),
                                       "mainStat": main_stat.text().strip() or None}
            payload["characters"][key] = {"level": self.manual_level.value(), "ascension": self.manual_ascension.value(),
                "constellation": self.manual_constellation.value(),
                "weapon": ({"key": weapon_key, "level": self.manual_weapon_level.value(),
                            "ascension": self.manual_weapon_ascension.value()} if weapon_key else None),
                "talents": {name: spin.value() for name, spin in self.manual_talents.items()},
                "artifacts": artifacts}
            self.editor.setPlainText(json.dumps(payload, ensure_ascii=False, indent=2))
            QMessageBox.information(self, "Account Snapshot", f"Đã thêm {key} vào snapshot JSON.")
        except Exception as exc:
            QMessageBox.warning(self, "Account Snapshot", str(exc))


class TargetWorker(QRunnable):
    def __init__(self, generation: int, *, path: str | None = None, payload: object = None,
                 selected: set[str] | None = None, operation_id: str | None = None,
                 preview_only: bool = False, controller=None):
        super().__init__()
        self.generation = generation
        self.path = path
        self.payload = payload
        self.selected = selected
        self.operation_id = operation_id
        self.preview_only = preview_only
        self.controller = controller
        self.signals = WorkerSignals()

    def run(self):
        try:
            result = (self.controller.preview_file(self.path) if self.path else
                      self.controller.preview_payload(self.payload) if self.preview_only else
                      self.controller.commit(self.payload, self.selected, self.operation_id))
            self.signals.loaded.emit(self.generation, result)
        except Exception as exc:
            log.exception("Target JSON %s failed", "preview" if self.path or self.preview_only else "commit")
            self.signals.failed.emit(self.generation, str(exc))


class ArtifactWorker(QRunnable):
    def __init__(self, generation: int, payload: object, *, snapshot_id: str | None = None,
                 rows: list[dict] | None = None, controller=None):
        super().__init__()
        self.generation, self.payload = generation, payload
        self.snapshot_id, self.rows = snapshot_id, rows
        self.controller = controller
        self.signals = WorkerSignals()

    def run(self):
        try:
            result = (self.controller.confirm(self.rows or [], self.snapshot_id or "")
                      if self.rows is not None else self.controller.preview(self.payload))
            self.signals.loaded.emit(self.generation, result)
        except Exception as exc:
            log.exception("Artifact evaluation operation failed")
            self.signals.failed.emit(self.generation, str(exc))


class TargetSelectionDialog(QDialog):
    def __init__(self, preview: dict, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Target JSON preview · partial commit")
        self.resize(760, 600)
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel(f"Hợp lệ: {len(preview['validTargets'])} · "
                                f"Không hợp lệ: {len(preview['invalidTargets'])} · "
                                f"Không sở hữu: {len(preview['unknownCharacters'])} · "
                                f"Sẽ ghi mới/cập nhật: {preview.get('willCreateOrUpdate', 0)} · "
                                f"Ghi đè target hiện tại: {len(preview.get('overwrites', []))}"))
        layout.addWidget(QLabel("Chọn target cần commit. Bỏ chọn, lỗi hoặc nhân vật không sở hữu sẽ giữ nguyên."))
        self.items = QListWidget()
        details = {item["characterKey"]: item for item in preview.get("validTargetDetails", [])}
        for key in preview["validTargets"]:
            detail = details.get(key, {})
            target = detail.get("target") or {}
            previous_version = detail.get("currentVersion")
            version_label = f"ghi đè v{previous_version} → v{previous_version + 1}" if previous_version else "tạo v1"
            enabled_talents = [f"{name} {item['target']}" for name, item in
                               (target.get("talents") or {}).items() if item.get("enabled")]
            weapon = target.get("weapon") or {}
            artifact = target.get("artifact") or {}
            summary = (f"Lv {target.get('level', '?')}/A{target.get('ascension', '?')} · "
                       f"{' / '.join(enabled_talents) or 'không nâng talent'} · "
                       f"weapon Lv {weapon.get('targetLevel', '?')} · "
                       f"artifact {artifact.get('targetQuality', 'off') if artifact.get('enabled') else 'off'}")
            row = QListWidgetItem(f"{key} · {version_label} · {summary}")
            row.setData(Qt.ItemDataRole.UserRole, key)
            row.setFlags(row.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            row.setCheckState(Qt.CheckState.Checked)
            notes = (target.get("notes") or "").strip()
            row.setToolTip((summary + (f"\nGhi chú: {notes}" if notes else "")))
            self.items.addItem(row)
        layout.addWidget(self.items, 1)
        selection_actions = QHBoxLayout()
        select_all = QPushButton("Chọn tất cả hợp lệ")
        select_all.clicked.connect(lambda: [self.items.item(i).setCheckState(Qt.CheckState.Checked)
                                            for i in range(self.items.count())])
        select_none = QPushButton("Bỏ chọn tất cả")
        select_none.clicked.connect(lambda: [self.items.item(i).setCheckState(Qt.CheckState.Unchecked)
                                             for i in range(self.items.count())])
        selection_actions.addWidget(select_all); selection_actions.addWidget(select_none)
        selection_actions.addStretch(); layout.addLayout(selection_actions)
        warnings = [f"{item['characterKey']}: {item['message']} ({item['field']})"
                    for item in preview["invalidTargets"]]
        warnings.extend(f"Không sở hữu: {key}" for key in preview["unknownCharacters"])
        if warnings:
            info = QTextEdit()
            info.setReadOnly(True)
            info.setPlainText("\n".join(warnings))
            layout.addWidget(info)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok |
                                   QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText("Commit dòng đã chọn")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def selected_keys(self) -> set[str]:
        return {self.items.item(index).data(Qt.ItemDataRole.UserRole) for index in range(self.items.count())
                if self.items.item(index).checkState() == Qt.CheckState.Checked}


class ArtifactSelectionDialog(QDialog):
    def __init__(self, preview: dict, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Artifact evaluation preview")
        self.resize(700, 540)
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel(f"Hợp lệ: {preview['validCount']} · Tổng: {len(preview['evaluations'])}"))
        layout.addWidget(QLabel("Chọn evaluation hợp lệ để xác nhận. Dữ liệu chỉ được ghi sau bước này."))
        self.items = QListWidget()
        self.rows = {}
        messages = []
        for row in preview["evaluations"]:
            key = row.get("characterKey") or f"Dòng {row['index'] + 1}"
            quality = row.get("quality") or {}
            score = quality.get("normalizedScore")
            label = quality.get("qualityLabel") or quality.get("qualityStatus") or "unknown"
            item = QListWidgetItem(f"{key} · {label}" + (f" · {score:.2f}" if isinstance(score, (int, float)) else ""))
            if row["valid"]:
                item.setData(Qt.ItemDataRole.UserRole, row["index"])
                item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
                item.setCheckState(Qt.CheckState.Checked)
                self.rows[row["index"]] = row
            else:
                item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEnabled)
                messages.extend(f"{key}: {issue.get('message', issue.get('code'))}" for issue in row["errors"])
            messages.extend(f"{key}: {warning}" for warning in row["warnings"])
            self.items.addItem(item)
        layout.addWidget(self.items, 1)
        if messages:
            info = QTextEdit(); info.setReadOnly(True); info.setPlainText("\n".join(messages))
            layout.addWidget(info)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok |
                                   QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept); buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def selected_rows(self) -> list[dict]:
        return [self.rows[self.items.item(index).data(Qt.ItemDataRole.UserRole)]
                for index in range(self.items.count())
                if self.items.item(index).data(Qt.ItemDataRole.UserRole) is not None
                and self.items.item(index).checkState() == Qt.CheckState.Checked]


class SettingsWorker(QRunnable):
    def __init__(self, generation: int, controller, payload: dict | None = None):
        super().__init__()
        self.generation, self.payload = generation, payload
        self.controller = controller
        self.signals = WorkerSignals()

    def run(self):
        try:
            result = (self.controller.save(self.payload["planner"], self.payload["artifact"], self.payload["account"])
                      if self.payload is not None else self.controller.load())
            self.signals.loaded.emit(self.generation, result)
        except Exception as exc:
            log.exception("Settings operation failed")
            self.signals.failed.emit(self.generation, str(exc))


class PinWorker(QRunnable):
    def __init__(self, generation: int, character_key: str | None, commit: bool, controller=None):
        super().__init__()
        self.generation, self.character_key, self.commit = generation, character_key, commit
        self.controller = controller
        self.signals = WorkerSignals()

    def run(self):
        try:
            result = (self.controller.set_pin(self.character_key) if self.commit
                      else self.controller.preview_pin(self.character_key or ""))
            self.signals.loaded.emit(self.generation, result)
        except Exception as exc:
            log.exception("Today pin operation failed")
            self.signals.failed.emit(self.generation, str(exc))


class PlanRunWorker(QRunnable):
    def __init__(self, generation: int, run_id: str | None = None, controller=None):
        super().__init__()
        self.generation, self.run_id = generation, run_id
        self.controller = controller
        self.signals = WorkerSignals()

    def run(self):
        try:
            result = self.controller.replay_run(self.run_id) if self.run_id else self.controller.list_runs()
            self.signals.loaded.emit(self.generation, result)
        except Exception as exc:
            log.exception("PlanRun operation failed")
            self.signals.failed.emit(self.generation, str(exc))


class TeamsWorker(QRunnable):
    def __init__(self, generation: int, controller, rows: list[dict] | None = None):
        super().__init__()
        self.generation, self.rows = generation, rows
        self.controller = controller
        self.signals = WorkerSignals()

    def run(self):
        try:
            result = self.controller.save(self.rows) if self.rows is not None else self.controller.load()
            self.signals.loaded.emit(self.generation, result)
        except Exception as exc:
            log.exception("Team configuration failed")
            self.signals.failed.emit(self.generation, str(exc))


class CharacterConfigWorker(QRunnable):
    def __init__(self, generation: int, controller, character_key: str, payload: dict | None = None):
        super().__init__()
        self.generation = generation
        self.character_key = character_key
        self.controller = controller
        self.payload = payload
        self.signals = WorkerSignals()

    def run(self):
        try:
            result = (self.controller.save(
                self.character_key,
                tier_key=self.payload.get("tierKey"),
                priority_override=self.payload["priorityOverride"],
            ) if self.payload is not None else
                self.controller.load(self.character_key))
            self.signals.loaded.emit(self.generation, result)
        except Exception as exc:
            log.exception("Character planner configuration failed")
            self.signals.failed.emit(self.generation, str(exc))


class TargetPresetWorker(QRunnable):
    def __init__(self, generation: int, character_key: str, controller, *,
                 create_label: str | None = None, activate_key: str | None = None):
        super().__init__()
        self.generation = generation
        self.character_key = character_key
        self.controller = controller
        self.create_label = create_label
        self.activate_key = activate_key
        self.signals = WorkerSignals()

    def run(self):
        try:
            if self.create_label is not None:
                result = self.controller.create_preset(self.character_key, self.create_label)
            elif self.activate_key is not None:
                result = self.controller.activate_preset(self.character_key, self.activate_key)
            else:
                raise ValueError("Preset operation is missing.")
            self.signals.loaded.emit(self.generation, result)
        except Exception as exc:
            log.exception("Target preset operation failed")
            self.signals.failed.emit(self.generation, str(exc))


class TeamsDialog(QDialog):
    def __init__(self, data: dict, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Team management")
        self.resize(800, 580)
        layout = QVBoxLayout(self)
        imported = QTextEdit(); imported.setReadOnly(True); imported.setMaximumHeight(130)
        imported.setPlainText("GOOD teams (quan sát, read-only):\n" + ("\n".join(
            f"{row['name']}: {', '.join(row['members'])}" for row in data["importedTeams"]) or "Không có"))
        layout.addWidget(imported)
        layout.addWidget(QLabel("Planner teams: dùng canonical character key. Chỉ một team có thể là Đội chính."))
        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["ID", "Tên", "Members", "Đội chính"])
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setTabKeyNavigation(True)
        for row in data["configuredTeams"]:
            self._append(row["teamId"], row["name"], ", ".join(row["members"]), row.get("isPrimary", False))
        self.table.resizeColumnsToContents()
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setCurrentCell(0, 0) if self.table.rowCount() else None
        layout.addWidget(self.table, 1)
        actions = QHBoxLayout()
        add = QPushButton("Thêm team"); remove = QPushButton("Xóa dòng")
        add.clicked.connect(lambda: self._append("", "", "", False))
        remove.clicked.connect(self._remove_selected)
        actions.addWidget(add); actions.addWidget(remove); actions.addStretch()
        layout.addLayout(actions)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save |
                                   QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept); buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _append(self, team_id: str, name: str, members: str, is_primary: bool):
        row = self.table.rowCount(); self.table.insertRow(row)
        self.table.setItem(row, 0, QTableWidgetItem(team_id))
        self.table.setItem(row, 1, QTableWidgetItem(name))
        self.table.setItem(row, 2, QTableWidgetItem(members))
        primary = QTableWidgetItem("")
        primary.setFlags(primary.flags() | Qt.ItemFlag.ItemIsUserCheckable)
        primary.setCheckState(Qt.CheckState.Checked if is_primary else Qt.CheckState.Unchecked)
        self.table.setItem(row, 3, primary)

    def _remove_selected(self):
        if self.table.currentRow() >= 0:
            self.table.removeRow(self.table.currentRow())

    def rows(self) -> list[dict]:
        result = []
        for index in range(self.table.rowCount()):
            value = lambda column: (self.table.item(index, column).text().strip()
                                    if self.table.item(index, column) else "")
            result.append({"teamId": value(0), "name": value(1),
                           "members": [item.strip() for item in value(2).split(",") if item.strip()],
                           "isPrimary": bool(self.table.item(index, 3) and
                                             self.table.item(index, 3).checkState() == Qt.CheckState.Checked)})
        return result


class PlanRunDialog(QDialog):
    def __init__(self, rows: list[dict], parent=None):
        super().__init__(parent)
        self.setWindowTitle("PlanRun history")
        self.resize(760, 520)
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Chọn một decision đã ghi để replay bằng input và context lịch sử."))
        self.items = QListWidget()
        for row in rows:
            primary = row.get("primaryTask") or {}
            item = QListWidgetItem(f"{row['createdAt']} · {primary.get('title', 'Không có primary task')}")
            item.setData(Qt.ItemDataRole.UserRole, row["id"])
            self.items.addItem(item)
        if self.items.count(): self.items.setCurrentRow(0)
        layout.addWidget(self.items, 1)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Open |
                                   QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept); buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def selected_run(self) -> str | None:
        item = self.items.currentItem()
        return item.data(Qt.ItemDataRole.UserRole) if item else None


class HistoryDialog(QDialog):
    def __init__(self, payload: dict, parent=None):
        super().__init__(parent)
        self.setWindowTitle("History")
        self.resize(820, 600)
        layout = QVBoxLayout(self)

        items = payload.get("items", [])
        groups = payload.get("groups") or {
            "accountProgress": [row for row in items if row.get("source") == "SNAPSHOT"],
            "targetConfigChanges": [row for row in items if row.get("source") == "CONFIG"],
            "completionChanges": [row for row in items if row.get("source") == "DERIVED"],
        }
        tabs = QTabWidget()
        for key, title, empty in (
            ("accountProgress", "Account progress", "Chưa có GOOD snapshot."),
            ("targetConfigChanges", "Targets & config", "Chưa có thay đổi target/cấu hình."),
            ("completionChanges", "Completion", "Chưa có chuyển trạng thái completion."),
        ):
            rows = groups.get(key, [])
            view = QTextEdit()
            view.setReadOnly(True)
            text = "\n".join(
                f"{item['when']} · {item['event']}" +
                (f" · {item['character']}" if item.get("character") else "")
                for item in rows
            )
            view.setPlainText(text or empty)
            tabs.addTab(view, f"{title} · {len(rows)}")
        layout.addWidget(QLabel(
            "Account progress = dữ liệu GOOD quan sát được. Completion được tính theo target hiện tại trên snapshot đã chọn; target/config edits nằm riêng."))
        layout.addWidget(tabs, 1)

        snapshots = payload.get("snapshots", [])
        if len(snapshots) >= 2:
            layout.addWidget(QLabel("So sánh hai GOOD snapshot:"))
            row = QHBoxLayout()
            self.before = QComboBox()
            self.after = QComboBox()
            for snapshot in reversed(snapshots):
                label = f"#{snapshot['snapshotIndex']} · {snapshot['when']}"
                self.before.addItem(label, snapshot["id"])
                self.after.addItem(label, snapshot["id"])
            # Default to the latest transition: previous -> current.
            self.before.setCurrentIndex(max(0, self.before.count() - 2))
            self.after.setCurrentIndex(self.after.count() - 1)
            row.addWidget(QLabel("Từ"))
            row.addWidget(self.before, 1)
            row.addWidget(QLabel("Đến"))
            row.addWidget(self.after, 1)
            layout.addLayout(row)
            compare = QPushButton("So sánh snapshot")
            compare.clicked.connect(self.accept)
            layout.addWidget(compare)
        else:
            self.before = self.after = None
            layout.addWidget(QLabel("Cần ít nhất hai snapshot để so sánh."))

        close = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        close.rejected.connect(self.reject)
        layout.addWidget(close)

    def selected_pair(self) -> tuple[str, str] | None:
        if self.before is None or self.after is None:
            return None
        before = self.before.currentData()
        after = self.after.currentData()
        if not before or not after:
            return None
        return str(before), str(after)


class CharacterConfigDialog(QDialog):
    def __init__(self, data: dict, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"Planner config · {data['characterKey']}")
        self.resize(520, 260)
        layout = QVBoxLayout(self)
        form = QFormLayout()
        self.tier = QComboBox()
        self.tier.addItem("Chưa xếp hạng", None)
        for item in sorted(data["tiers"], key=lambda row: (int(row.get("order", 0)), row["key"])):
            self.tier.addItem(f"{item['label']} ({item['key']})", item["key"])
        current_tier = data.get("tierKey")
        for index in range(self.tier.count()):
            if self.tier.itemData(index) == current_tier:
                self.tier.setCurrentIndex(index)
                break
        self.priority = QComboBox()
        for label, value in (("Ưu tiên", "PRIORITIZED"), ("Bình thường", "NORMAL"),
                             ("Hạ ưu tiên", "DEPRIORITIZED")):
            self.priority.addItem(label, value)
        for index in range(self.priority.count()):
            if self.priority.itemData(index) == data.get("priorityOverride", "NORMAL"):
                self.priority.setCurrentIndex(index)
                break
        form.addRow("Tier", self.tier)
        form.addRow("Priority override", self.priority)
        layout.addLayout(form)
        active = next((row for row in data.get("presets", []) if row.get("active")), None)
        layout.addWidget(QLabel("Target preset active: " +
                                (f"{active['label']} ({active['key']})" if active else "chưa có target")))
        layout.addWidget(QLabel("Tier/override chỉ đổi thứ tự chiến lược; pin Today là cấu hình riêng."))
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save |
                                   QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept); buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def payload(self) -> dict:
        return {"tierKey": self.tier.currentData(),
                "priorityOverride": self.priority.currentData()}


class TargetEditorDialog(QDialog):
    """Form-based target authoring; commits still pass through the JSON preview flow."""
    def __init__(self, characters: list[dict], selected_key: str | None, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Thiết lập mục tiêu nhân vật")
        self.resize(620, 720)
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Chọn preset, chỉnh các mốc rồi chọn nhân vật áp dụng. Có thể sửa Tier/Priority và Team riêng ở màn Nhân vật."))
        self.preset = QComboBox()
        self.preset.addItem("DPS · Lv90 / E10 / Q9 / vũ khí 90", "DPS")
        self.preset.addItem("Support · Lv90 / E9 / Q9 / vũ khí 90", "SUPPORT")
        self.preset.addItem("Đầu tư cơ bản · Lv90 / vũ khí 90", "BASIC")
        layout.addWidget(self.preset)
        form = QFormLayout()
        self.level = QSpinBox(); self.level.setRange(1, 90); self.level.setValue(90)
        self.ascension = QSpinBox(); self.ascension.setRange(0, 6); self.ascension.setValue(6)
        form.addRow("Level", self.level); form.addRow("Đột phá", self.ascension)
        self.skill_on = QCheckBox("Đặt mục tiêu kỹ năng"); self.skill_on.setChecked(True)
        self.skill_level = QSpinBox(); self.skill_level.setRange(1, 10); self.skill_level.setValue(10)
        self.burst_on = QCheckBox("Đặt mục tiêu nộ"); self.burst_on.setChecked(True)
        self.burst_level = QSpinBox(); self.burst_level.setRange(1, 10); self.burst_level.setValue(9)
        self.normal_on = QCheckBox("Đặt mục tiêu đánh thường")
        self.normal_level = QSpinBox(); self.normal_level.setRange(1, 10); self.normal_level.setValue(1)
        form.addRow(self.normal_on, self.normal_level); form.addRow(self.skill_on, self.skill_level); form.addRow(self.burst_on, self.burst_level)
        self.weapon_level = QSpinBox(); self.weapon_level.setRange(1, 90); self.weapon_level.setValue(90)
        form.addRow("Vũ khí đến level", self.weapon_level)
        self.artifact_on = QCheckBox("Theo dõi mục tiêu chất lượng artifact")
        self.artifact_quality = QComboBox(); self.artifact_quality.addItems(["ACCEPTABLE", "GOOD", "EXCELLENT"]); self.artifact_quality.setCurrentText("GOOD")
        self.artifact_sets = QLineEdit(); self.artifact_sets.setPlaceholderText("Set key cách nhau bằng dấu phẩy (tùy chọn)")
        form.addRow(self.artifact_on, self.artifact_quality); form.addRow("Artifact set ưu tiên", self.artifact_sets)
        layout.addLayout(form)
        layout.addWidget(QLabel("Áp dụng cho các nhân vật đã chọn:"))
        self.characters = QListWidget()
        self.characters.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        for character in characters:
            key = character["key"]
            item = QListWidgetItem(key)
            item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            item.setCheckState(Qt.CheckState.Checked if key == selected_key else Qt.CheckState.Unchecked)
            self.characters.addItem(item)
        layout.addWidget(self.characters, 1)
        self.preset.currentIndexChanged.connect(self._apply_preset)
        self._apply_preset()
        existing = next((row.get("target") for row in characters if row.get("key") == selected_key and row.get("target")), None)
        if existing:
            self.level.setValue(int(existing.get("level", 90)))
            self.ascension.setValue(int(existing.get("ascension", 6)))
            talents = existing.get("talents") or {}
            for name, enabled_box, level_box in (("normal", self.normal_on, self.normal_level),
                                                  ("skill", self.skill_on, self.skill_level),
                                                  ("burst", self.burst_on, self.burst_level)):
                item = talents.get(name) or {}
                enabled_box.setChecked(bool(item.get("enabled", False)))
                level_box.setValue(int(item.get("target", 1)))
            weapon = existing.get("weapon") or {}
            self.weapon_level.setValue(int(weapon.get("targetLevel", 90)))
            artifact = existing.get("artifact") or {}
            self.artifact_on.setChecked(bool(artifact.get("enabled", False)))
            quality = artifact.get("targetQuality", "GOOD")
            if quality in ("ACCEPTABLE", "GOOD", "EXCELLENT"):
                self.artifact_quality.setCurrentText(quality)
            self.artifact_sets.setText(", ".join(artifact.get("primarySets") or []))
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept); buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _apply_preset(self):
        preset = self.preset.currentData()
        self.level.setValue(90); self.ascension.setValue(6); self.weapon_level.setValue(90)
        self.normal_on.setChecked(preset == "DPS"); self.normal_level.setValue(9 if preset == "DPS" else 1)
        self.skill_on.setChecked(preset != "BASIC"); self.skill_level.setValue(10 if preset == "DPS" else 9)
        self.burst_on.setChecked(preset != "BASIC"); self.burst_level.setValue(9)

    def payload(self) -> dict:
        selected = [self.characters.item(i).text() for i in range(self.characters.count())
                    if self.characters.item(i).checkState() == Qt.CheckState.Checked]
        if not selected:
            raise ValueError("Chọn ít nhất một nhân vật.")
        sets = [value.strip() for value in self.artifact_sets.text().split(",") if value.strip()]
        target = {
            "level": self.level.value(), "ascension": self.ascension.value(),
            "importance": {"level": 1.0, "ascension": 1.0},
            "talents": {
                "normal": {"enabled": self.normal_on.isChecked(), "target": self.normal_level.value(), "importance": 1.0 if self.normal_on.isChecked() else 0.0},
                "skill": {"enabled": self.skill_on.isChecked(), "target": self.skill_level.value(), "importance": 1.0 if self.skill_on.isChecked() else 0.0},
                "burst": {"enabled": self.burst_on.isChecked(), "target": self.burst_level.value(), "importance": 1.0 if self.burst_on.isChecked() else 0.0}},
            "weapon": {"weaponKey": None, "targetLevel": self.weapon_level.value(), "importance": 0.8},
            "artifact": {"enabled": self.artifact_on.isChecked(), "targetQuality": self.artifact_quality.currentText(),
                         "importance": 0.8, "primarySets": sets, "alternativeSets": [],
                         "gate": {"minLevel": self.level.value(), "minAscension": self.ascension.value(),
                                  "weaponMinLevel": self.weapon_level.value(), "requiredTalents": [key for key, enabled in (("normal", self.normal_on.isChecked()), ("skill", self.skill_on.isChecked()), ("burst", self.burst_on.isChecked())) if enabled]}},
            "notes": ""}
        return {"version": 1, "targets": {key: target for key in selected}}


class SettingsDialog(QDialog):
    def __init__(self, data: dict, parent=None):
        super().__init__(parent)
        self.data = data
        self.setWindowTitle("Settings")
        self.resize(560, 620)
        layout = QVBoxLayout(self)
        form = QFormLayout()
        account = data["account"]
        self.region = QComboBox(); self.region.addItems(["ASIA", "EUROPE", "AMERICA", "TW_HK_MO"])
        self.region.setCurrentText(account["serverRegion"]); form.addRow("Server", self.region)
        self.language = QLineEdit(account["gameLanguage"]); form.addRow("Game language", self.language)
        self.world_level = QSpinBox(); self.world_level.setRange(0, 9); self.world_level.setValue(account["worldLevel"])
        form.addRow("World Level", self.world_level)
        self.resin = QSpinBox(); self.resin.setRange(-1, 200); self.resin.setSpecialValueText("unknown")
        self.resin.setValue(-1 if account["resin"] is None else account["resin"]); form.addRow("Resin", self.resin)
        self.weekly_claimed = QLineEdit(", ".join(account["weeklyClaimed"]))
        self.weekly_claimed.setPlaceholderText("Boss/source keys đã claim, phân cách dấu phẩy")
        form.addRow("Weekly claimed", self.weekly_claimed)
        self.unavailable_sources = QLineEdit(", ".join(account["unavailableSources"]))
        self.unavailable_sources.setPlaceholderText("Source keys tạm khóa, phân cách dấu phẩy")
        form.addRow("Temporary unavailable", self.unavailable_sources)
        self.switch_threshold = QDoubleSpinBox()
        self.switch_threshold.setRange(0, 1000); self.switch_threshold.setDecimals(2)
        self.switch_threshold.setValue(float(data["planner"]["reorderThreshold"]))
        form.addRow("Today switch threshold", self.switch_threshold)
        self.manual_order_enabled = QCheckBox("Bật manual order trong cùng tier")
        self.manual_order_enabled.setChecked(bool(data["planner"].get("manualOrderEnabled", False)))
        form.addRow("Manual order", self.manual_order_enabled)
        self.manual_order = QLineEdit(", ".join(data["planner"].get("manualOrder", [])))
        self.manual_order.setPlaceholderText("Nahida, Yelan, Furina…")
        form.addRow("Thứ tự character", self.manual_order)
        self.adapter = QComboBox(); self.adapter.addItems(["rv", "cv", "rank_percent", "custom_score"])
        self.adapter.setCurrentText(data["artifact"]["adapterType"])
        form.addRow("Artifact metric", self.adapter)
        self.thresholds = {}
        for label in ("POOR", "ACCEPTABLE", "GOOD", "EXCELLENT"):
            field = QLineEdit()
            value = data["artifact"]["thresholds"].get(label)
            field.setText("" if value is None else str(value))
            field.setPlaceholderText("để trống nếu chưa cấu hình")
            form.addRow(label, field); self.thresholds[label] = field
        layout.addWidget(_scrollable_form(form), 1)
        explanation = QLabel("RV / CV / custom score: ngưỡng tăng dần. Akasha rankPercent là top %, ngưỡng giảm dần (nhỏ hơn tốt hơn).")
        explanation.setWordWrap(True)
        explanation.setObjectName("secondaryText")
        layout.addWidget(explanation)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save |
                                   QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept); buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def payload(self) -> dict:
        planner = dict(self.data["planner"])
        planner["reorderThreshold"] = self.switch_threshold.value()
        manual_order = [value.strip() for value in self.manual_order.text().split(",") if value.strip()]
        if len(manual_order) != len(set(manual_order)):
            raise ValueError("Manual order không được chứa character trùng nhau.")
        planner["manualOrderEnabled"] = self.manual_order_enabled.isChecked()
        planner["manualOrder"] = manual_order
        values = {key: field.text().strip() for key, field in self.thresholds.items()}
        if any(values.values()) and not all(values.values()):
            raise ValueError("Hãy nhập đủ cả bốn ngưỡng artifact hoặc để trống toàn bộ.")
        thresholds = {key: (float(value) if value else None) for key, value in values.items()}
        return {"planner": planner,
                "artifact": {"adapterType": self.adapter.currentText(), "thresholds": thresholds},
                "account": {"serverRegion": self.region.currentText(),
                    "gameLanguage": self.language.text().strip(), "worldLevel": self.world_level.value(),
                    "resin": None if self.resin.value() < 0 else self.resin.value(),
                    "weeklyClaimed": [value.strip() for value in self.weekly_claimed.text().split(",") if value.strip()],
                    "unavailableSources": [value.strip() for value in self.unavailable_sources.text().split(",") if value.strip()]}}


class SupportWorker(QRunnable):
    def __init__(self, generation: int, action: str, value: object = None,
                 game_data_controller=None, support_controller=None):
        super().__init__()
        self.generation, self.action, self.value = generation, action, value
        self.game_data_controller = game_data_controller
        self.support_controller = support_controller
        self.signals = WorkerSignals()

    def run(self):
        try:
            if self.action == "history":
                result = self.support_controller.history()
            elif self.action == "history_compare":
                before, after = self.value
                result = self.support_controller.compare_history(before, after)
            elif self.action == "health":
                result = self.support_controller.data_health()
            elif self.action == "backup":
                result = self.support_controller.create_backup(str(self.value))
            elif self.action == "restore":
                result = self.support_controller.restore_backup(str(self.value))
            elif self.action == "gamedata_status":
                result = self.game_data_controller.status()
            elif self.action == "gamedata_preview":
                result = self.game_data_controller.preview(str(self.value))
            elif self.action == "gamedata_install":
                result = self.game_data_controller.install(str(self.value))
            elif self.action == "gamedata_export":
                result = self.game_data_controller.export(str(self.value))
            else:
                raise ValueError(f"Unsupported support action: {self.action}")
            self.signals.loaded.emit(self.generation, result)
        except Exception as exc:
            log.exception("Desktop support action failed: %s", self.action)
            self.signals.failed.emit(self.generation, str(exc))


class MainWindow(QMainWindow):
    def __init__(self, account_import_controller, settings_controller, teams_controller,
                 character_configuration_controller, game_data_controller, artifact_exchange_controller,
                 planner_state_controller, target_controller, tier_pack_controller, support_controller,
                 overview_controller, build_intent_controller=None):
        super().__init__()
        self.account_import_controller = account_import_controller
        self.settings_controller = settings_controller
        self.teams_controller = teams_controller
        self.character_configuration_controller = character_configuration_controller
        self.game_data_controller = game_data_controller
        self.artifact_exchange_controller = artifact_exchange_controller
        self.planner_state_controller = planner_state_controller
        self.target_controller = target_controller
        self.tier_pack_controller = tier_pack_controller
        self.support_controller = support_controller
        self.overview_controller = overview_controller
        self.build_intent_controller = build_intent_controller
        self.setWindowTitle("Genshin Account Progression Planner")
        self.resize(1260, 780)
        self.setMinimumSize(800, 560)
        # Native control arrows and placeholders also need a dark palette.
        palette = self.palette()
        for role, token in ((QPalette.ColorRole.Window, "background"),
                            (QPalette.ColorRole.Base, "surface"),
                            (QPalette.ColorRole.AlternateBase, "elevated"),
                            (QPalette.ColorRole.Button, "elevated"),
                            (QPalette.ColorRole.Text, "text"),
                            (QPalette.ColorRole.WindowText, "text"),
                            (QPalette.ColorRole.ButtonText, "text"),
                            (QPalette.ColorRole.PlaceholderText, "secondary"),
                            (QPalette.ColorRole.Highlight, "accent"),
                            (QPalette.ColorRole.HighlightedText, "background")):
            palette.setColor(role, QColor(COLORS[token]))
        self.setPalette(palette)
        self.setStyleSheet(DESKTOP_STYLE)

        root = QWidget()
        self.setCentralWidget(root)
        layout = QHBoxLayout(root)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # Sidebar
        sidebar = QFrame()
        sidebar.setObjectName("sidebar")
        self.sidebar = sidebar
        sidebar.setFixedWidth(224)
        sidebar_layout = QVBoxLayout(sidebar)
        sidebar_layout.setContentsMargins(16, 26, 16, 20)
        sidebar_layout.setSpacing(4)

        brand_row = QHBoxLayout()
        brand_row.setSpacing(10)
        brand_glyph = QLabel("✦")
        brand_glyph.setObjectName("brandGlyph")
        brand_row.addWidget(brand_glyph)

        brand_text = QVBoxLayout()
        brand_text.setSpacing(0)
        brand_title = QLabel("GENSHIN")
        brand_title.setObjectName("brandTitle")
        brand_subtitle = QLabel("ACCOUNT PLANNER")
        brand_subtitle.setObjectName("brandSubtitle")
        brand_text.addWidget(brand_title)
        brand_text.addWidget(brand_subtitle)
        brand_row.addLayout(brand_text)
        brand_row.addStretch()
        sidebar_layout.addLayout(brand_row)
        sidebar_layout.addSpacing(18)

        divider = QFrame()
        divider.setObjectName("sidebarDivider")
        divider.setFixedHeight(1)
        sidebar_layout.addWidget(divider)
        sidebar_layout.addSpacing(14)

        self.nav = QListWidget()
        self.nav.setObjectName("navList")
        self.nav.setItemDelegate(NavigationDelegate(self.nav))
        self.nav.setMouseTracking(True)
        self.nav.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.nav.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.nav.setFrameShape(QFrame.Shape.NoFrame)
        self.nav.addItems(["Tiếp theo", "Lộ trình", "Nhân vật", "Tier List"])
        self.nav.setAccessibleName("Điều hướng chính")
        for index, description in enumerate((
            "Việc nên làm hôm nay", "Thứ tự nâng cấp toàn tài khoản",
            "Tiến trình và build của từng nhân vật", "Xếp hạng và ưu tiên nhân vật",
        )):
            self.nav.item(index).setToolTip(f"{description} · Ctrl+{index + 1}")
        self.nav.currentRowChanged.connect(self._switch)
        sidebar_layout.addWidget(self.nav, 1)
        sidebar_layout.addStretch()

        sidebar_footer = QLabel("Dữ liệu lưu trên máy")
        sidebar_footer.setWordWrap(True)
        sidebar_footer.setObjectName("sidebarFooter")
        self.account_summary = QLabel("Tài khoản của bạn")
        self.account_summary.setObjectName("sidebarFooter")
        self.account_summary.setWordWrap(True)
        sidebar_layout.addWidget(self.account_summary)
        layout.addWidget(sidebar)

        # Main Panel
        main_panel = QWidget()
        main = QVBoxLayout(main_panel)
        self.main_layout = main
        main.setContentsMargins(32, 26, 32, 20)
        main.setSpacing(16)
        layout.addWidget(main_panel, 1)

        # Page context stays above actions so narrow windows do not clip controls.
        header = QFrame()
        header.setObjectName("pageHeader")
        header_layout = QVBoxLayout(header)
        header_layout.setContentsMargins(0, 0, 0, 10)
        header_layout.setSpacing(5)
        self.page_title = QLabel("Tiếp theo")
        self.page_title.setObjectName("pageTitle")
        self.page_description = QLabel()
        self.page_description.setObjectName("pageSubtitle")
        self.page_description.setWordWrap(True)
        header_title_row = QHBoxLayout()
        header_title_row.addWidget(self.page_title, 1)
        header_layout.addLayout(header_title_row)
        header_layout.addWidget(self.page_description)
        main.addWidget(header)

        # Consolidated Toolbar
        toolbar = QHBoxLayout()
        toolbar.setSpacing(8)


        self.target_button = QPushButton("Target JSON…")
        self.target_button.clicked.connect(self.import_targets)
        self.target_button.setVisible(False)

        self.snapshot_button = QToolButton()
        self.snapshot_button.setText("Nhập tài khoản")
        self.snapshot_button.setObjectName("primaryButton")
        self.snapshot_button.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)
        self.snapshot_button.setPopupMode(QToolButton.ToolButtonPopupMode.MenuButtonPopup)
        self.snapshot_button.setToolTip("Nhập hoặc chỉnh sửa Account Snapshot; mở mũi tên để nhập file GOOD")
        self.snapshot_button.setAccessibleName("Nhập tài khoản hoặc file GOOD")
        self.snapshot_button.clicked.connect(self.import_snapshot)
        account_menu = QMenu(self.snapshot_button)
        account_menu.addAction("Nhập / chỉnh sửa Account Snapshot…", self.import_snapshot)
        self.good_import_action = account_menu.addAction("Nhập file GOOD…", self.import_good)
        self.snapshot_button.setMenu(account_menu)
        sidebar_layout.addWidget(self.snapshot_button)

        # Additional tools instantiated on self for backward-compatibility
        self.artifact_button = QPushButton("Artifact…")
        self.artifact_button.clicked.connect(self.import_artifacts)
        self.history_button = QPushButton("History…")
        self.history_button.clicked.connect(self.open_history)
        self.runs_button = QPushButton("Plan Runs…")
        self.runs_button.clicked.connect(lambda: self._run_plan_runs())
        self.health_button = QPushButton("Data Health…")
        self.health_button.clicked.connect(self.open_data_health)
        self.settings_button = QPushButton("Settings…")
        self.settings_button.clicked.connect(self.open_settings)
        self.teams_button = QPushButton("Teams…")
        self.teams_button.clicked.connect(lambda: self._run_teams())
        self.backup_button = QPushButton("Backup…")
        self.backup_button.clicked.connect(self.export_backup)
        self.restore_button = QPushButton("Restore…")
        self.restore_button.clicked.connect(self.restore_backup)
        self.logs_button = QPushButton("Logs")
        self.logs_button.clicked.connect(self.open_logs)

        # Group tools without changing their controllers or busy-state guards.
        self.tools_button = QPushButton("Công cụ")
        self.tools_button.setAccessibleName("Công cụ lập kế hoạch, dữ liệu và hỗ trợ")
        tools_menu = QMenu(self.tools_button)
        planning_menu = tools_menu.addMenu("Lập kế hoạch")
        data_menu = tools_menu.addMenu("Dữ liệu")
        support_menu = tools_menu.addMenu("Hỗ trợ")
        self._tool_actions = []
        self.theater_button = QPushButton("Chuẩn bị Nhà Hát…")
        self.theater_button.clicked.connect(self.open_theater_preparation)
        for menu, text, button in (
            (planning_menu, "Chuẩn bị Nhà Hát…", self.theater_button),
            (planning_menu, "Đánh giá Artifact…", self.artifact_button),
            (planning_menu, "Đội hình…", self.teams_button),
            (planning_menu, "Lịch sử thay đổi…", self.history_button),
            (planning_menu, "Nhật ký kế hoạch…", self.runs_button),
            (data_menu, "Kiểm tra dữ liệu…", self.health_button),
            (data_menu, "Sao lưu dữ liệu…", self.backup_button),
            (data_menu, "Khôi phục dữ liệu…", self.restore_button),
            (support_menu, "Cài đặt tài khoản…", self.settings_button),
            (support_menu, "Mở thư mục Logs", self.logs_button),
        ):
            action = menu.addAction(text, button.click)
            self._tool_actions.append((action, button))
        data_menu.addAction("GameData trên máy…", self.open_game_data)
        for menu in (tools_menu, planning_menu, data_menu, support_menu):
            menu.aboutToShow.connect(self._sync_tool_actions)
        self.tools_button.setMenu(tools_menu)
        toolbar.addStretch(1)
        self.export_results_button = QPushButton("Xuất kết quả…")
        self.export_results_button.setToolTip("Xuất báo cáo, JSON và mẫu nhận xét để đánh giá kết quả")
        self.export_results_button.setEnabled(False)
        self.export_results_button.clicked.connect(self.export_planner_results)
        toolbar.addWidget(self.export_results_button)
        sidebar_layout.addWidget(self.tools_button)
        sidebar_layout.addSpacing(12)
        sidebar_layout.addWidget(sidebar_footer)

        self.refresh_button = QPushButton("Tính lại")
        self.refresh_button.setToolTip("Tính lại kế hoạch từ dữ liệu hiện tại · Ctrl+R")
        self.refresh_button.clicked.connect(self.refresh)
        toolbar.addWidget(self.refresh_button)

        header_title_row.addLayout(toolbar)

        self.feedback_banner = QFrame()
        self.feedback_banner.setObjectName("feedbackBanner")
        feedback_layout = QHBoxLayout(self.feedback_banner)
        feedback_layout.setContentsMargins(12, 8, 12, 8)
        self.feedback_text = QLabel()
        self.feedback_text.setWordWrap(True)
        self.feedback_text.setAccessibleName("Trạng thái cập nhật kế hoạch")
        feedback_layout.addWidget(self.feedback_text, 1)
        self.retry_button = QPushButton("Thử lại")
        self.retry_button.clicked.connect(self.refresh_button.click)
        feedback_layout.addWidget(self.retry_button)
        self.feedback_banner.hide()
        main.addWidget(self.feedback_banner)

        # Stacked Pages
        self.pages = QStackedWidget()
        main.addWidget(self.pages, 1)

        self._make_today()
        self._make_roadmap()
        self._make_characters()
        self._make_tier_list()

        self.today_title.setTextFormat(Qt.TextFormat.PlainText)
        self.today_action.setTextFormat(Qt.TextFormat.PlainText)
        self.today_why.setTextFormat(Qt.TextFormat.PlainText)
        self.char_name.setTextFormat(Qt.TextFormat.PlainText)
        self.today_material_table.setAccessibleName("Nguyên liệu cần cho bước nâng tiếp theo")
        self.roadmap_tree.setAccessibleName("Lộ trình nâng cấp toàn tài khoản")
        self.tier_table.setAccessibleName("Xếp hạng và ưu tiên nhân vật")
        self.roadmap_filter.setAccessibleName("Lọc lộ trình theo trạng thái")
        self.export_results_button.setToolTip("Nhập tài khoản và tính kế hoạch để xuất kết quả")
        self._navigation_shortcuts = []
        for index in range(self.nav.count()):
            shortcut = QShortcut(QKeySequence(f"Ctrl+{index + 1}"), self)
            shortcut.activated.connect(lambda row=index: self.nav.setCurrentRow(row))
            self._navigation_shortcuts.append(shortcut)
        self._refresh_shortcut = QShortcut(QKeySequence("Ctrl+R"), self)
        self._refresh_shortcut.activated.connect(self.refresh_button.click)
        self._search_shortcut = QShortcut(QKeySequence("Ctrl+F"), self)
        self._search_shortcut.activated.connect(self._focus_page_search)
        self.nav.setCurrentRow(0)
        self._pool = QThreadPool(self)
        self._generation = 0
        self._loading = False
        self._workers = []
        self._data = None
        self.statusBar().showMessage("Đang mở dữ liệu local…")
        QTimer.singleShot(0, self.refresh)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if hasattr(self, "sidebar"):
            compact = self.width() < 1100
            self.sidebar.setFixedWidth(168 if compact else 224)
            self.main_layout.setContentsMargins(12 if compact else 32, 20 if compact else 26,
                                               12 if compact else 32, 16)
            self.nav.doItemsLayout()

    def _sync_tool_actions(self):
        for action, button in self._tool_actions:
            action.setEnabled(button.isEnabled())

    def _show_feedback(self, text, *, error=False):
        self.feedback_text.setText(text)
        set_state(self.feedback_banner, "error" if error else "")
        self.retry_button.setVisible(error)
        self.feedback_banner.show()

    def _make_today(self):
        page = QWidget()
        page_layout = QVBoxLayout(page)
        page_layout.setContentsMargins(0, 0, 0, 0)
        page_layout.setSpacing(12)


        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        container = QWidget()
        body = QVBoxLayout(container)
        body.setContentsMargins(0, 0, 6, 0)
        body.setSpacing(14)

        # 1. Hero Action Card
        hero_card = QFrame()
        hero_card.setObjectName("primary")
        hero_layout = QVBoxLayout(hero_card)
        hero_layout.setContentsMargins(24, 24, 24, 22)
        hero_layout.setSpacing(18)
        hero_main = QHBoxLayout()
        hero_main.setSpacing(18)

        self.today_avatar = QLabel()
        self.today_avatar.setFixedSize(76, 76)
        self.today_avatar.setAlignment(Qt.AlignmentFlag.AlignCenter)
        hero_main.addWidget(self.today_avatar)

        hero_center = QVBoxLayout()
        hero_center.setSpacing(6)
        eyebrow_row = QHBoxLayout()
        eyebrow = QLabel("Hành động đề xuất hôm nay")
        eyebrow.setObjectName("eyebrow")
        eyebrow.setWordWrap(True)
        eyebrow_row.addWidget(eyebrow, 1)

        self.today_badge = QLabel("")
        self.today_badge.setWordWrap(True)
        self.today_badge.setObjectName("badge")
        eyebrow_row.addWidget(self.today_badge)
        eyebrow_row.addStretch()
        hero_center.addLayout(eyebrow_row)

        self.today_title = QLabel("Đang tính kế hoạch…")
        self.today_title.setObjectName("headline")
        self.today_title.setWordWrap(True)
        hero_center.addWidget(self.today_title)

        self.today_action = QLabel("")
        self.today_action.setObjectName("todayAction")
        self.today_action.setWordWrap(True)
        hero_center.addWidget(self.today_action)

        self.today_why = QLabel("")
        self.today_why.setObjectName("secondaryText")
        self.today_why.setWordWrap(True)
        hero_center.addWidget(self.today_why)

        self.today_setup_target = QPushButton("Thiết lập mục tiêu đầu tiên")
        self.today_setup_target.setObjectName("primaryButton")
        self.today_setup_target.clicked.connect(self.open_target_editor)
        self.today_setup_target.setVisible(False)
        hero_center.addWidget(self.today_setup_target)
        self.today_import_button = QPushButton("Nhập tài khoản")
        self.today_import_button.setObjectName("primaryButton")
        self.today_import_button.clicked.connect(self.snapshot_button.click)
        self.today_import_button.hide()
        hero_center.addWidget(self.today_import_button, 0, Qt.AlignmentFlag.AlignLeft)

        hero_main.addLayout(hero_center, 1)
        hero_layout.addLayout(hero_main)

        hero_right = ResponsiveCardGrid(120, 3)

        self.today_resin_badge = QLabel("")
        self.today_resin_badge.setObjectName("fact")
        self.today_resin_badge.setWordWrap(True)
        hero_right.add_card(self.today_resin_badge)

        self.today_avail_badge = QLabel("")
        self.today_avail_badge.setObjectName("fact")
        self.today_avail_badge.setWordWrap(True)
        hero_right.add_card(self.today_avail_badge)

        self.today_source_label = QLabel("")
        self.today_source_label.setObjectName("fact")
        self.today_source_label.setAlignment(Qt.AlignmentFlag.AlignLeft)
        self.today_source_label.setWordWrap(True)
        hero_right.add_card(self.today_source_label)

        hero_layout.addWidget(hero_right)
        journey = QHBoxLayout()
        self.today_roadmap_button = QPushButton("Xem lộ trình")
        self.today_roadmap_button.setObjectName("ghostButton")
        self.today_roadmap_button.clicked.connect(lambda: self.nav.setCurrentRow(1))
        self.today_characters_button = QPushButton("Xem nhân vật")
        self.today_characters_button.setObjectName("ghostButton")
        self.today_characters_button.clicked.connect(lambda: self.nav.setCurrentRow(2))
        journey.addWidget(self.today_roadmap_button)
        journey.addWidget(self.today_characters_button)
        journey.addStretch()
        hero_layout.addLayout(journey)
        body.addWidget(hero_card)

        # 2. Materials Table Card
        mat_card = QFrame()
        mat_card.setObjectName("surfaceCard")
        mat_layout = QVBoxLayout(mat_card)
        mat_layout.setContentsMargins(18, 16, 18, 16)
        mat_layout.setSpacing(10)

        mat_header_row = QHBoxLayout()
        mat_title = QLabel("Chuẩn bị nguyên liệu")
        mat_title.setObjectName("section")
        mat_header_row.addWidget(mat_title)
        mat_header_row.addStretch()

        mat_layout.addLayout(mat_header_row)

        self.today_material_empty = QLabel(
            "Nguyên liệu sẽ xuất hiện khi có hành động được đề xuất."
        )
        self.today_material_empty.setObjectName("pageSubtitle")
        self.today_material_empty.setWordWrap(True)
        mat_layout.addWidget(self.today_material_empty)
        self.today_material_note = QLabel("Nguyên liệu cần cho bước nâng tiếp theo; không thể hiện tồn kho tài khoản.")
        self.today_material_note.setObjectName("pageSubtitle")
        self.today_material_note.setWordWrap(True)
        mat_layout.addWidget(self.today_material_note)
        self.today_material_table = QTableWidget(0, 2)
        self.today_material_table.setHorizontalHeaderLabels([
            "Nguyên liệu", "Cần cho bước nâng"
        ])
        self.today_material_table.setAlternatingRowColors(True)
        self.today_material_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.today_material_table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.today_material_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.today_material_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.today_material_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.today_material_table.verticalHeader().setVisible(False)
        self.today_material_table.verticalHeader().setMinimumSectionSize(48)
        self.today_material_table.verticalHeader().setDefaultSectionSize(48)
        self.today_material_table.setWordWrap(True)
        self.today_material_table.setMinimumHeight(100)
        self.today_material_table.setShowGrid(False)
        mat_layout.addWidget(self.today_material_table)
        self.today_material_table.model().rowsInserted.connect(self._sync_today_material_view)
        self.today_material_table.model().rowsRemoved.connect(self._sync_today_material_view)
        self._sync_today_material_view()


        body.addWidget(mat_card)

        # 3. Info & Alternatives Card
        self.today_details_button = QPushButton("Thông tin bổ sung")
        self.today_details_button.setToolTip("Thông tin tài khoản và các phương án thay thế")
        self.today_details_button.setObjectName("ghostButton")
        self.today_details_button.setCheckable(True)
        body.addWidget(self.today_details_button, 0, Qt.AlignmentFlag.AlignLeft)
        self.today_details_panel = QWidget()
        bottom_row = ResponsiveCardGrid(200, 2)
        details_layout = QVBoxLayout(self.today_details_panel)
        details_layout.setContentsMargins(0, 0, 0, 0)
        details_layout.addWidget(bottom_row)
        self.today_details_panel.hide()
        self.today_details_button.toggled.connect(self.today_details_panel.setVisible)

        info_card = QFrame()
        info_card.setObjectName("surfaceCard")
        info_layout = QVBoxLayout(info_card)
        info_layout.setContentsMargins(16, 14, 16, 14)
        info_layout.setSpacing(8)
        info_title = QLabel("Thông tin tài khoản & kế hoạch")
        info_title.setObjectName("secondaryText")
        info_title.setWordWrap(True)
        info_layout.addWidget(info_title)
        self.today_meta_info = QLabel("Đang chờ dữ liệu…")
        self.today_meta_info.setObjectName("secondaryText")
        self.today_meta_info.setWordWrap(True)
        info_layout.addWidget(self.today_meta_info)
        info_layout.addStretch()
        bottom_row.add_card(info_card)

        alt_card = QFrame()
        alt_card.setObjectName("surfaceCard")
        alt_layout = QVBoxLayout(alt_card)
        alt_layout.setContentsMargins(16, 14, 16, 14)
        alt_layout.setSpacing(8)
        alt_title = QLabel("Phương án thay thế")
        alt_title.setObjectName("secondaryText")
        alt_title.setWordWrap(True)
        alt_layout.addWidget(alt_title)
        self.today_alternatives_list = QListWidget()
        self.today_alternatives_list.setFixedHeight(120)
        alt_layout.addWidget(self.today_alternatives_list)
        bottom_row.add_card(alt_card)

        body.addWidget(self.today_details_panel)

        # Retain hidden QTextEdit for backward-compatible access
        self.today_context = QTextEdit()
        self.today_context.setReadOnly(True)
        self.today_context.setVisible(False)
        body.addWidget(self.today_context)

        body.addStretch()
        scroll.setWidget(container)
        page_layout.addWidget(scroll, 1)
        self.pages.addWidget(page)

    def _sync_today_material_view(self, *_args):
        has_rows = self.today_material_table.rowCount() > 0
        height = self.today_material_table.horizontalHeader().sizeHint().height()
        height += sum(self.today_material_table.rowHeight(row)
                      for row in range(self.today_material_table.rowCount())) + 4
        self.today_material_table.setFixedHeight(min(320, max(100, height)))
        self.today_material_table.setVisible(has_rows)
        self.today_material_empty.setVisible(not has_rows)
        self.today_material_note.setVisible(has_rows)

    def _make_roadmap(self):
        page = QWidget()
        body = QVBoxLayout(page)
        body.setSpacing(12)


        self.roadmap_summary = QLabel("")
        self.roadmap_summary.setObjectName("pageSubtitle")
        self.roadmap_summary.setWordWrap(True)
        body.addWidget(self.roadmap_summary)
        self.roadmap_setup_target = QPushButton("Thiết lập mục tiêu đầu tiên")
        self.roadmap_setup_target.setObjectName("primaryButton")
        self.roadmap_setup_target.clicked.connect(self.open_target_editor)
        self.roadmap_setup_target.setVisible(False)
        body.addWidget(self.roadmap_setup_target, 0, Qt.AlignmentFlag.AlignLeft)

        # Search and Filter Bar
        filter_bar = QHBoxLayout()
        filter_bar.setSpacing(10)

        self.roadmap_search = QLineEdit()
        self.roadmap_search.setClearButtonEnabled(True)
        self.roadmap_search.setAccessibleName("Tìm nhân vật")
        self.roadmap_search.setToolTip("Tìm trong màn hình hiện tại · Ctrl+F")
        self.roadmap_search.setPlaceholderText("Tìm nhân vật hoặc thành phần…")
        self.roadmap_search.textChanged.connect(self._filter_roadmap)
        filter_bar.addWidget(self.roadmap_search, 1)

        self.roadmap_filter = QComboBox()
        self.roadmap_filter.addItems([
            "Tất cả trạng thái",
            "Có thể tiến hành (ACTIONABLE)",
            "Đang chờ điều kiện (BLOCKED)",
            "Đã đạt (READY)",
            "Hoàn tất (COMPLETE)",
        ])
        self.roadmap_filter.currentIndexChanged.connect(self._filter_roadmap)
        filter_bar.addWidget(self.roadmap_filter)

        self.roadmap_details_toggle = QCheckBox("Chi tiết")
        self.roadmap_details_toggle.setToolTip("Hiển thị target cuối / tiến triển và điểm ưu tiên")
        self.roadmap_details_toggle.toggled.connect(self._configure_roadmap_columns)
        filter_bar.addWidget(self.roadmap_details_toggle)
        body.addLayout(filter_bar)

        self.roadmap_tree = QTreeWidget()
        self.roadmap_tree.setHeaderLabels(["#", "Nhân vật / thành phần", "Hiện tại", "Mốc tiếp",
                                           "Target cuối", "Trạng thái", "Điểm ưu tiên"])
        self.roadmap_tree.setRootIsDecorated(False)
        self.roadmap_tree.setAlternatingRowColors(True)
        self.roadmap_tree.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.roadmap_tree.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.roadmap_tree.itemDoubleClicked.connect(self._open_goal_character)
        self.roadmap_tree.setWordWrap(True)
        self._configure_roadmap_columns(False)
        body.addWidget(self.roadmap_tree)
        self.roadmap_search_feedback = QLabel()
        self.roadmap_search_feedback.setObjectName("searchFeedback")
        self.roadmap_search_feedback.setWordWrap(True)
        footer = QHBoxLayout()
        footer.addWidget(self.roadmap_search_feedback, 1)
        self.roadmap_open_details_button = QPushButton("Xem mục đang chọn")
        self.roadmap_open_details_button.setEnabled(False)
        self.roadmap_open_details_button.clicked.connect(self._open_roadmap_details)
        footer.addWidget(self.roadmap_open_details_button)
        body.addLayout(footer)
        self.roadmap_tree.itemSelectionChanged.connect(self._update_roadmap_detail_action)
        self._roadmap_details_shortcut = QShortcut(QKeySequence("Return"), self.roadmap_tree)
        self._roadmap_details_shortcut.setContext(Qt.ShortcutContext.WidgetShortcut)
        self._roadmap_details_shortcut.activated.connect(self.roadmap_open_details_button.click)
        self.roadmap_open_details_button.setToolTip("Đọc đầy đủ nội dung, kể cả cột ẩn · Enter")
        self.pages.addWidget(page)

    def _update_roadmap_detail_action(self):
        item = self.roadmap_tree.currentItem()
        self.roadmap_open_details_button.setEnabled(
            item is not None and item.isSelected() and not item.isHidden()
        )

    def _roadmap_details_dialog(self):
        item = self.roadmap_tree.currentItem()
        if item is None or not item.isSelected() or item.isHidden():
            return None
        fields = tuple((self.roadmap_tree.headerItem().text(column), item.text(column))
                       for column in range(self.roadmap_tree.columnCount()))
        details = "\n".join(dict.fromkeys(item.toolTip(column) for column in range(item.columnCount())
                                         if item.toolTip(column)))
        return RowDetailsDialog(item.text(1), fields, details, self)

    def _open_roadmap_details(self):
        dialog = self._roadmap_details_dialog()
        if dialog is not None:
            dialog.exec()
            dialog.deleteLater()

    def _configure_roadmap_columns(self, detailed):
        tree = self.roadmap_tree
        header = tree.header()
        header.setStretchLastSection(False)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        for column, width in {0: 42, 2: 70, 3: 90, 4: 240, 5: 120, 6: 74}.items():
            header.setSectionResizeMode(column, QHeaderView.ResizeMode.Fixed)
            tree.setColumnWidth(column, width)
        for column in range(tree.columnCount()):
            tree.headerItem().setToolTip(column, tree.headerItem().text(column))
        tree.headerItem().setToolTip(3, "Milestone kế tiếp trong chuỗi nâng cấp")
        for column in (4, 6):
            tree.setColumnHidden(column, not detailed)

    def _filter_roadmap(self):
        query = self.roadmap_search.text().strip().casefold()
        filter_idx = self.roadmap_filter.currentIndex()
        status_map = {1: "ACTIONABLE", 2: "BLOCKED", 3: "READY", 4: "COMPLETE"}
        target_status = status_map.get(filter_idx)

        for i in range(self.roadmap_tree.topLevelItemCount()):
            item = self.roadmap_tree.topLevelItem(i)
            char_key = str(item.data(0, Qt.ItemDataRole.UserRole) or "")
            col_text = " ".join(item.text(col) for col in range(item.columnCount())).casefold()
            raw_status = str(item.data(5, Qt.ItemDataRole.UserRole) or "")

            matches_query = not query or query in char_key.casefold() or query in col_text
            matches_status = not target_status or raw_status == target_status
            item.setHidden(not (matches_query and matches_status))
        if hasattr(self, "roadmap_search_feedback"):
            total = self.roadmap_tree.topLevelItemCount()
            visible = sum(not self.roadmap_tree.topLevelItem(i).isHidden() for i in range(total))
            self.roadmap_search_feedback.setText(
                "Không có kết quả. Thử từ khóa khác hoặc chọn tất cả trạng thái."
                if total and not visible else f"Hiển thị {visible} / {total} mục"
            )
        self._update_roadmap_detail_action()

    def _make_characters(self):
        page = QWidget()
        body = QVBoxLayout(page)
        body.setSpacing(12)


        splitter = QSplitter(Qt.Orientation.Horizontal)

        # Left Panel: Search + Character List
        left_panel = QWidget()
        left_layout = QVBoxLayout(left_panel)
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.setSpacing(8)

        self.character_search = QLineEdit()
        self.character_search.setClearButtonEnabled(True)
        self.character_search.setAccessibleName("Tìm nhân vật")
        self.character_search.setToolTip("Tìm trong màn hình hiện tại · Ctrl+F")
        self.character_search.setPlaceholderText("Tìm nhân vật…")
        self.character_search.textChanged.connect(self._filter_characters)
        left_layout.addWidget(self.character_search)

        self.character_list = QListWidget()
        self.character_list.currentRowChanged.connect(self._show_character)
        left_layout.addWidget(self.character_list, 1)
        self.character_search_feedback = QLabel()
        self.character_search_feedback.setObjectName("searchFeedback")
        self.character_search_feedback.setWordWrap(True)
        left_layout.addWidget(self.character_search_feedback)

        splitter.addWidget(left_panel)

        # Right Panel: Tabs (Visual Dashboard + Raw Text)
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(8)

        char_tabs = QTabWidget()

        # Tab 1: Visual Dashboard
        visual_scroll = QScrollArea()
        visual_scroll.setWidgetResizable(True)
        visual_scroll.setFrameShape(QFrame.Shape.NoFrame)
        visual_container = QWidget()
        visual_layout = QVBoxLayout(visual_container)
        visual_layout.setContentsMargins(4, 4, 8, 4)
        visual_layout.setSpacing(14)

        # Character Header Card
        header_card = QFrame()
        header_card.setObjectName("primary")
        header_layout = QHBoxLayout(header_card)
        header_layout.setContentsMargins(14, 10, 14, 10)
        header_layout.setSpacing(16)

        self.char_avatar = QLabel()
        self.char_avatar.setFixedSize(76, 76)
        self.char_avatar.setAlignment(Qt.AlignmentFlag.AlignCenter)
        header_layout.addWidget(self.char_avatar)

        header_info = QVBoxLayout()
        header_info.setSpacing(6)
        self.char_name = QLabel("Chọn nhân vật")
        self.char_name.setObjectName("headline")
        self.char_name.setWordWrap(True)
        header_info.addWidget(self.char_name)

        badges_row = ResponsiveCardGrid(100, 2)
        self.char_tier_badge = QLabel("Mức độ liên quan: tự suy luận")
        self.char_tier_badge.setObjectName("badge")
        self.char_tier_badge.setWordWrap(True)
        badges_row.add_card(self.char_tier_badge)

        self.char_preset_badge = QLabel("Preset: default")
        self.char_preset_badge.setObjectName("badge")
        self.char_preset_badge.setWordWrap(True)
        badges_row.add_card(self.char_preset_badge)

        self.char_pin_badge = QLabel("Chưa pin")
        self.char_pin_badge.setObjectName("badge")
        self.char_pin_badge.setWordWrap(True)
        badges_row.add_card(self.char_pin_badge)

        self.char_priority_badge = QLabel("Priority: 0")
        self.char_priority_badge.setObjectName("badge")
        self.char_priority_badge.setWordWrap(True)
        badges_row.add_card(self.char_priority_badge)
        header_info.addWidget(badges_row)
        header_layout.addLayout(header_info, 1)
        visual_layout.addWidget(header_card)

        # Progress Comparison Grid (Level, Talents, Weapon)
        prog_row = ResponsiveCardGrid(170, 3)

        # Level Box
        lvl_box = QFrame()
        lvl_box.setObjectName("surfaceCard")
        lvl_box_layout = QVBoxLayout(lvl_box)
        lvl_box_layout.setContentsMargins(14, 12, 14, 12)
        lvl_box_layout.setSpacing(6)
        lvl_title = QLabel("Cấp độ và đột phá")
        lvl_title.setObjectName("eyebrow")
        lvl_box_layout.addWidget(lvl_title)
        self.char_level_val = QLabel("-")
        self.char_level_val.setObjectName("todayAction")
        lvl_box_layout.addWidget(self.char_level_val)
        self.char_level_progress = QProgressBar()
        self.char_level_progress.setTextVisible(False)
        self.char_level_progress.setAccessibleName("Tiến trình cấp độ nhân vật")
        self.char_level_progress.setRange(0, 100)
        self.char_level_progress.setValue(0)
        lvl_box_layout.addWidget(self.char_level_progress)
        prog_row.add_card(lvl_box)

        # Talents Box
        tal_box = QFrame()
        tal_box.setObjectName("surfaceCard")
        tal_box_layout = QVBoxLayout(tal_box)
        tal_box_layout.setContentsMargins(14, 12, 14, 12)
        tal_box_layout.setSpacing(6)
        tal_title = QLabel("THIÊN PHÚ")
        tal_title.setObjectName("eyebrow")
        tal_box_layout.addWidget(tal_title)
        self.char_talent_val = QLabel("-")
        self.char_talent_val.setWordWrap(True)
        self.char_talent_val.setObjectName("todayAction")
        tal_box_layout.addWidget(self.char_talent_val)
        prog_row.add_card(tal_box)

        # Weapon Box
        wpn_box = QFrame()
        wpn_box.setObjectName("surfaceCard")
        wpn_box_layout = QVBoxLayout(wpn_box)
        wpn_box_layout.setContentsMargins(14, 12, 14, 12)
        wpn_box_layout.setSpacing(6)
        wpn_title = QLabel("VŨ KHÍ")
        wpn_title.setObjectName("eyebrow")
        wpn_box_layout.addWidget(wpn_title)

        wpn_content = QHBoxLayout()
        self.char_weapon_avatar = QLabel()
        self.char_weapon_avatar.setFixedSize(48, 48)
        self.char_weapon_avatar.setAlignment(Qt.AlignmentFlag.AlignCenter)
        wpn_content.addWidget(self.char_weapon_avatar)

        self.char_weapon_val = QLabel("-")
        self.char_weapon_val.setObjectName("todayAction")
        self.char_weapon_val.setWordWrap(True)
        wpn_content.addWidget(self.char_weapon_val, 1)
        wpn_box_layout.addLayout(wpn_content)

        prog_row.add_card(wpn_box)
        visual_layout.addWidget(prog_row)

        # 5 Artifacts Grid
        art_card = QFrame()
        art_card.setObjectName("surfaceCard")
        art_layout = QVBoxLayout(art_card)
        art_layout.setContentsMargins(14, 12, 14, 12)
        art_layout.setSpacing(10)

        art_header = QHBoxLayout()
        art_heading = QLabel("Thánh di vật đang mặc")
        art_heading.setWordWrap(True)
        art_heading.setObjectName("section")
        art_header.addWidget(art_heading, 1)
        art_header.addStretch()
        self.char_artifact_summary = QLabel("RV tổng: -")
        self.char_artifact_summary.setWordWrap(True)
        self.char_artifact_summary.setObjectName("eyebrow")
        art_header.addWidget(self.char_artifact_summary)
        art_layout.addLayout(art_header)

        self.char_art_slots_layout = ResponsiveCardGrid(130, 5)

        slot_titles = ["Hoa", "Lông", "Đồng hồ", "Ly", "Nón"]
        self.char_art_set = []
        self.char_art_main = []
        self.char_art_subs = []
        self.char_art_rv = []

        for name in slot_titles:
            slot_box = QFrame()
            slot_box.setObjectName("artifactSlot")
            slot_v = QVBoxLayout(slot_box)
            slot_v.setContentsMargins(8, 8, 8, 8)
            slot_v.setSpacing(4)

            lbl_title = QLabel(name)
            lbl_title.setObjectName("eyebrow")
            slot_v.addWidget(lbl_title)

            lbl_set = QLabel("-")
            lbl_set.setObjectName("secondaryText")
            lbl_set.setWordWrap(True)
            slot_v.addWidget(lbl_set)
            self.char_art_set.append(lbl_set)

            lbl_main = QLabel("-")
            lbl_main.setObjectName("eyebrow")
            lbl_main.setWordWrap(True)
            slot_v.addWidget(lbl_main)
            self.char_art_main.append(lbl_main)

            lbl_subs = QLabel("-")
            lbl_subs.setObjectName("secondaryText")
            lbl_subs.setWordWrap(True)
            slot_v.addWidget(lbl_subs, 1)
            lbl_subs.hide()
            self.char_art_subs.append(lbl_subs)

            lbl_rv = QLabel("RV -")
            lbl_rv.setObjectName("badge")
            lbl_rv.setAlignment(Qt.AlignmentFlag.AlignCenter)
            slot_v.addWidget(lbl_rv)
            self.char_art_rv.append(lbl_rv)

            self.char_art_slots_layout.add_card(slot_box)

        art_layout.addWidget(self.char_art_slots_layout)
        self.char_substats_toggle = QPushButton("Xem chỉ số phụ")
        self.char_substats_toggle.setObjectName("ghostButton")
        self.char_substats_toggle.setCheckable(True)
        self.char_substats_toggle.toggled.connect(self._set_artifact_substats_visible)
        art_layout.addWidget(self.char_substats_toggle, 0, Qt.AlignmentFlag.AlignLeft)

        self.char_artifact_gate = QLabel("")
        self.char_artifact_gate.setWordWrap(True)
        self.char_artifact_gate.setObjectName("secondaryText")
        art_layout.addWidget(self.char_artifact_gate)

        visual_layout.addWidget(art_card)

        # Teams & Planner Notes Card
        notes_card = QFrame()
        notes_card.setObjectName("surfaceCard")
        notes_layout = QVBoxLayout(notes_card)
        notes_layout.setContentsMargins(14, 12, 14, 12)
        notes_layout.setSpacing(6)

        notes_title = QLabel("ĐỘI HÌNH & THIẾT LẬP TARGET")
        notes_title.setObjectName("eyebrow")
        notes_layout.addWidget(notes_title)

        self.char_teams_val = QLabel("Đội hình: -")
        self.char_teams_val.setWordWrap(True)
        self.char_teams_val.setObjectName("secondaryText")
        notes_layout.addWidget(self.char_teams_val)

        self.char_target_notes = QLabel("Target: -")
        self.char_target_notes.setWordWrap(True)
        self.char_target_notes.setObjectName("secondaryText")
        notes_layout.addWidget(self.char_target_notes)

        visual_layout.addWidget(notes_card)

        visual_layout.addStretch()
        visual_scroll.setWidget(visual_container)
        char_tabs.addTab(visual_scroll, "Trực quan")

        # Tab 2: Raw Text (for full detail / inspection)
        self.character_detail = QTextEdit()
        self.character_detail.setReadOnly(True)
        char_tabs.addTab(self.character_detail, "Dữ liệu Text")

        self.character_tabs = char_tabs
        right_layout.addWidget(char_tabs, 1)
        self.character_empty = QLabel("Chưa có nhân vật trong snapshot. Nhập tài khoản để xem trang bị và build.")
        self.character_empty.setWordWrap(True)
        self.character_empty.setObjectName("pageSubtitle")
        self.character_empty.hide()
        right_layout.addWidget(self.character_empty, 1)

        # Keep the common actions visible; secondary actions remain in a menu.
        pin_actions = ResponsiveCardGrid(110, 5)
        self.character_config_button = QPushButton("Cấu hình…")
        self.character_config_button.setToolTip("Tier, mức ưu tiên và cấu hình nhân vật")
        self.character_config_button.clicked.connect(self.open_character_config)
        self.pin_button = QPushButton("Ghim Today")
        self.pin_button.clicked.connect(self.preview_selected_pin)
        self.character_more_button = QPushButton("Thêm")
        character_menu = QMenu(self.character_more_button)
        self.create_preset_action = character_menu.addAction("Tạo preset…", self.create_selected_preset)
        self.activate_preset_action = character_menu.addAction("Đổi preset…", self.activate_selected_preset)
        character_menu.addSeparator()
        self.unpin_action = character_menu.addAction("Bỏ ghim Today", lambda: self._run_pin(None, commit=True))
        self.character_more_button.setMenu(character_menu)
        self.wants_build_button = QPushButton("Muốn build")
        self.wants_build_button.clicked.connect(self.toggle_wants_build)
        self.edit_rv_button = QPushButton("Điền RV…")
        self.edit_rv_button.setToolTip("Mở biểu mẫu snapshot hiện tại để nhập RV cho thánh di vật đang trang bị")
        self.edit_rv_button.clicked.connect(self.edit_selected_artifact_rv)
        character_menu.addSeparator()
        character_menu.addAction("Đã hoàn thành build", lambda: self.set_build_intent("COMPLETE"))
        character_menu.addAction("Bỏ ưu tiên build", lambda: self.set_build_intent("NORMAL"))
        pin_actions.add_card(self.character_config_button)
        pin_actions.add_card(self.wants_build_button)
        pin_actions.add_card(self.edit_rv_button)
        pin_actions.add_card(self.pin_button)
        pin_actions.add_card(self.character_more_button)
        right_layout.addWidget(pin_actions)

        splitter.addWidget(right_panel)
        splitter.setChildrenCollapsible(False)
        left_panel.setMinimumWidth(150)
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 3)
        splitter.setSizes([220, 740])
        body.addWidget(splitter, 1)
        self.pages.addWidget(page)

    def _set_artifact_substats_visible(self, visible):
        for label in self.char_art_subs:
            label.setVisible(visible)
        self.char_substats_toggle.setText("Ẩn chỉ số phụ" if visible else "Xem chỉ số phụ")

    def _filter_characters(self, query: str):
        query = query.strip().casefold()
        for i in range(self.character_list.count()):
            item = self.character_list.item(i)
            item.setHidden(bool(query and query not in item.text().casefold()))
        total = self.character_list.count()
        visible = sum(not self.character_list.item(i).isHidden() for i in range(total))
        self.character_search_feedback.setText(
            "Không tìm thấy nhân vật. Thử từ khóa khác."
            if total and not visible else f"Hiển thị {visible} / {total} nhân vật"
        )

    def _make_tier_list(self):
        page = QWidget(); layout = QVBoxLayout(page); layout.setSpacing(12)
        tier_help = QLabel("Điểm 0-100 quyết định hạng S+ đến D. Nhân vật chưa xếp hạng không tham gia roadmap tự động.")
        tier_help.setWordWrap(True)
        tier_help.setObjectName("pageSubtitle")
        layout.addWidget(tier_help)
        toolbar = QHBoxLayout()
        self.tier_search = QLineEdit(); self.tier_search.setPlaceholderText("Tìm nhân vật…")
        self.tier_search.setClearButtonEnabled(True)
        self.tier_search.setAccessibleName("Tìm nhân vật trong Tier List")
        self.tier_search.setToolTip("Tìm nhân vật · Ctrl+F")
        self.tier_search.textChanged.connect(self._filter_tier_list)
        toolbar.addWidget(self.tier_search, 1)
        toolbar.addWidget(QLabel("Tier tối thiểu"))
        self.tier_minimum = QComboBox()
        self.tier_minimum.addItems(["S+", "S", "A", "B", "C", "D"])
        toolbar.addWidget(self.tier_minimum)
        self.tier_details_toggle = QCheckBox("Chi tiết")
        self.tier_details_toggle.setToolTip("Hiển thị trạng thái sở hữu, ghi chú và build set")
        self.tier_details_toggle.toggled.connect(self._configure_tier_columns)
        toolbar.addWidget(self.tier_details_toggle)
        save = QPushButton("Lưu Tier List"); save.setObjectName("primaryButton")
        save.clicked.connect(self._save_tier_list)
        layout.addLayout(toolbar)
        file_actions = QHBoxLayout()
        file_actions.addWidget(save)
        self.tier_files_button = QPushButton("Tệp JSON")
        tier_files_menu = QMenu(self.tier_files_button)
        tier_files_menu.addAction("Nhập Tier List…", self._import_tier_list)
        tier_files_menu.addAction("Xuất Tier List…", self._export_tier_list)
        self.tier_files_button.setMenu(tier_files_menu)
        file_actions.addWidget(self.tier_files_button)
        file_actions.addStretch()
        layout.addLayout(file_actions)
        self.tier_table = QTableWidget(0, 7)
        self.tier_table.setHorizontalHeaderLabels(["Nhân vật", "Account", "Điểm", "Hạng", "Ghi chú", "Planner", "Build set"])
        self.tier_table.setAlternatingRowColors(True)
        self.tier_table.verticalHeader().setVisible(False)
        self.tier_table.verticalHeader().setDefaultSectionSize(40)
        self.tier_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.tier_table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self._configure_tier_columns(False)
        self.tier_table.itemChanged.connect(self._tier_item_changed)
        layout.addWidget(self.tier_table, 1)
        self.tier_search_feedback = QLabel()
        self.tier_search_feedback.setObjectName("searchFeedback")
        self.tier_search_feedback.setWordWrap(True)
        layout.addWidget(self.tier_search_feedback)
        self.pages.addWidget(page)

    def _configure_tier_columns(self, detailed):
        table = self.tier_table
        header = table.horizontalHeader()
        header.setStretchLastSection(False)
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        for column, width in {1: 84, 2: 58, 3: 52, 4: 180, 5: 150, 6: 210}.items():
            header.setSectionResizeMode(column, QHeaderView.ResizeMode.Fixed)
            table.setColumnWidth(column, width)
        for column in (1, 4, 6):
            table.setColumnHidden(column, not detailed)

    def _tier_item_changed(self, item):
        if item.column() != 2:
            return
        try:
            score = int(item.text().strip()) if item.text().strip() else None
            label = label_for(score) if score is None or 0 <= score <= 100 else "Sai điểm"
        except ValueError:
            label = "Sai điểm"
        self.tier_table.blockSignals(True)
        self.tier_table.item(item.row(), 3).setText(label)
        self.tier_table.blockSignals(False)

    def _render_tier_list(self):
        try:
            state = self.tier_pack_controller.load()
        except Exception as exc:
            self.statusBar().showMessage(f"Không thể đọc Tier List: {exc}")
            return
        self._tier_pack_current = state["pack"]
        self.tier_table.blockSignals(True)
        self.tier_table.setRowCount(len(state["rows"]))
        self.tier_minimum.setCurrentText(state["pack"]["minimumTierForRoadmap"])
        for index, row in enumerate(state["rows"]):
            for col, value in enumerate((row["characterKey"], "Sở hữu" if row["owned"] else "-",
                                         "" if row["score"] is None else str(row["score"]),
                                         row["tier"], row["notes"])):
                item = QTableWidgetItem(value)
                if col in (0, 1, 3):
                    item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                self.tier_table.setItem(index, col, item)
            control = QComboBox(); control.addItems(["NORMAL", "FORCE_INCLUDE", "IGNORE"])
            control.setCurrentText(row["control"])
            self.tier_table.setCellWidget(index, 5, control)
            chosen = QComboBox(); chosen.addItem("Tự suy luận", "")
            for set_key in row["setOptions"]:
                chosen.addItem(set_key, set_key)
            if row["selectedSet"]:
                position = chosen.findData(row["selectedSet"])
                if position >= 0: chosen.setCurrentIndex(position)
            self.tier_table.setCellWidget(index, 6, chosen)
        self.tier_table.blockSignals(False)
        self._filter_tier_list()

    def _filter_tier_list(self):
        query = self.tier_search.text().strip().casefold()
        for row in range(self.tier_table.rowCount()):
            key = self.tier_table.item(row, 0).text().casefold()
            self.tier_table.setRowHidden(row, bool(query and query not in key))
        if hasattr(self, "tier_search_feedback"):
            total = self.tier_table.rowCount()
            visible = sum(not self.tier_table.isRowHidden(row) for row in range(total))
            self.tier_search_feedback.setText(
                "Không tìm thấy nhân vật. Thử từ khóa khác."
                if total and not visible else f"Hiển thị {visible} / {total} nhân vật"
            )

    def _tier_payload_from_table(self):
        ratings, controls, selected_sets = {}, {}, {}
        for row in range(self.tier_table.rowCount()):
            key = self.tier_table.item(row, 0).text()
            raw = self.tier_table.item(row, 2).text().strip()
            score = int(raw) if raw else None
            if score is not None and not 0 <= score <= 100:
                raise ValueError(f"{key}: điểm phải từ 0 đến 100")
            note = self.tier_table.item(row, 4).text()
            if score is not None or note.strip():
                ratings[key] = {"score": score, "notes": note}
            control = self.tier_table.cellWidget(row, 5).currentText()
            if control != "NORMAL": controls[key] = control
            selected = self.tier_table.cellWidget(row, 6).currentData()
            if selected: selected_sets[key] = selected
        return {"version": 1, "ratings": ratings,
                "minimumTierForRoadmap": self.tier_minimum.currentText(),
                "controls": controls, "selectedSets": selected_sets}

    def _save_tier_list(self):
        try:
            saved = self.tier_pack_controller.save(self._tier_payload_from_table())
        except (ValueError, OSError) as exc:
            QMessageBox.warning(self, "Tier List", str(exc)); return
        self.statusBar().showMessage(f"Đã lưu Tier List v{saved['packVersion']}. Đang tính lại roadmap…")
        self.refresh()

    def _import_tier_list(self):
        path, _ = QFileDialog.getOpenFileName(self, "Import TierPack v1", "", "JSON (*.json)")
        if not path: return
        try:
            self.tier_pack_controller.import_file(path)
        except (ValueError, OSError, json.JSONDecodeError) as exc:
            QMessageBox.warning(self, "Tier List", str(exc)); return
        self._render_tier_list(); self.refresh()

    def _export_tier_list(self):
        path, _ = QFileDialog.getSaveFileName(self, "Export TierPack v1", "tier-pack.json", "JSON (*.json)")
        if not path: return
        try:
            self.tier_pack_controller.export_file(path, self._tier_payload_from_table())
        except (ValueError, OSError) as exc:
            QMessageBox.warning(self, "Tier List", str(exc))

    def _switch(self, index):
        if 0 <= index < self.pages.count():
            self.pages.setCurrentIndex(index)
            self.page_title.setText(("Tiếp theo", "Lộ trình", "Nhân vật", "Tier List")[index])
            self.page_description.setText((
                "Một hành động cụ thể hôm nay, kèm nguyên liệu và điều kiện cần thiết.",
                "Theo dõi thứ tự nâng cấp và các mốc tiến trình của toàn tài khoản.",
                "Xem snapshot hiện tại, trang bị và build cho từng nhân vật.",
                "Quản lý xếp hạng và mức ưu tiên để điều chỉnh lộ trình.",
            )[index])

    def _focus_page_search(self):
        search = {1: self.roadmap_search, 2: self.character_search, 3: self.tier_search}.get(
            self.pages.currentIndex()
        )
        if search is not None:
            search.setFocus(Qt.FocusReason.ShortcutFocusReason)
            search.selectAll()

    def refresh(self):
        if self._loading:
            return
        self._loading = True
        self._generation += 1
        generation = self._generation
        self.refresh_button.setEnabled(False)
        self.snapshot_button.setEnabled(False)
        self.good_import_action.setEnabled(False)
        self.target_button.setEnabled(False)
        self.artifact_button.setEnabled(False)
        self.history_button.setEnabled(False)
        self.health_button.setEnabled(False)
        self.settings_button.setEnabled(False)
        self.backup_button.setEnabled(False)
        self.restore_button.setEnabled(False)
        self.today_import_button.setEnabled(False)
        self._show_feedback("Đang tính kế hoạch từ dữ liệu hiện tại…")
        self._sync_tool_actions()
        self.statusBar().showMessage("Đang tính kế hoạch…")
        worker = OverviewWorker(generation, self.overview_controller)
        worker.signals.loaded.connect(self._loaded)
        worker.signals.failed.connect(self._failed)
        self._workers.append(worker)
        self._pool.start(worker)

    def _loaded(self, generation, data):
        if generation != self._generation:
            return
        self._loading = False
        self._workers.clear()
        self.refresh_button.setEnabled(True)
        self.snapshot_button.setEnabled(True)
        self.good_import_action.setEnabled(True)
        self.target_button.setEnabled(True)
        self.artifact_button.setEnabled(True)
        self.history_button.setEnabled(True)
        self.health_button.setEnabled(True)
        self.settings_button.setEnabled(True)
        self.backup_button.setEnabled(True)
        self.restore_button.setEnabled(True)
        self.today_import_button.setEnabled(True)
        self.feedback_banner.hide()
        self._sync_tool_actions()
        self._data = data
        self.export_results_button.setEnabled(data.get("snapshotId") is not None)
        self.export_results_button.setToolTip("Xuất báo cáo, JSON và mẫu nhận xét" if self.export_results_button.isEnabled() else "Nhập tài khoản và tính kế hoạch để xuất kết quả")
        self._render_today(data)
        self._render_roadmap(data)
        self._render_characters(data)
        self._render_tier_list()
        self.statusBar().showMessage("Đã cập nhật · " + datetime.now().strftime("%H:%M:%S"))

    def _failed(self, generation, message):
        if generation != self._generation:
            return
        self._loading = False
        self._workers.clear()
        self.refresh_button.setEnabled(True)
        self.snapshot_button.setEnabled(True)
        self.good_import_action.setEnabled(True)
        self.target_button.setEnabled(True)
        self.artifact_button.setEnabled(True)
        self.history_button.setEnabled(True)
        self.health_button.setEnabled(True)
        self.settings_button.setEnabled(True)
        self.backup_button.setEnabled(True)
        self.restore_button.setEnabled(True)
        self.statusBar().showMessage("Chưa cập nhật · đang hiển thị kế hoạch cũ" if self._data else "Không thể tải dữ liệu")
        self.today_import_button.setEnabled(True)
        self._sync_tool_actions()
        self._show_feedback(
            "Chưa cập nhật được kế hoạch. Đang giữ kết quả trước đó. Bạn có thể thử lại."
            if self._data else "Không thể tải kế hoạch. Kiểm tra dữ liệu hoặc thử lại.", error=True)
        self.feedback_text.setToolTip(message)
        log.warning("Overview refresh failed: %s", message)

    def export_planner_results(self):
        if not self._data or self._data.get("snapshotId") is None:
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Xuất kết quả để đánh giá", datetime.now().strftime("ProjectG-results-%Y%m%d-%H%M%S.zip"),
            "Gói đánh giá (*.zip)")
        if not path:
            return
        if not path.lower().endswith(".zip"):
            path += ".zip"
        try:
            export_results(path, self._data)
        except (OSError, TypeError, ValueError) as exc:
            QMessageBox.warning(self, "Không thể xuất kết quả", str(exc))
            return
        self.statusBar().showMessage(f"Đã xuất kết quả: {path}")
        QMessageBox.information(self, "Đã xuất kết quả", "Gói đánh giá gồm report.md, results.json và review.md.\n" + path)

    def import_good(self):
        if self._loading:
            return
        path, _ = QFileDialog.getOpenFileName(self, "Chọn GOOD snapshot", "", "JSON (*.json);;All files (*)")
        if path:
            self._run_good(path, commit=False)

    def import_snapshot(self):
        if self._loading:
            return
        dialog = SnapshotEditorDialog(self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        self._snapshot_payload = dialog.payload()
        self._run_snapshot(self._snapshot_payload, commit=False)

    def _run_snapshot(self, payload, *, commit: bool, allow_regression: bool = False):
        if self._loading:
            return
        self._loading = True
        self._generation += 1
        generation = self._generation
        self.refresh_button.setEnabled(False)
        self.good_import_action.setEnabled(False)
        self.snapshot_button.setEnabled(False)
        self.statusBar().showMessage("Đang lưu Account Snapshot…" if commit else "Đang phân tích Account Snapshot…")
        worker = SnapshotWorker(generation, payload, self.account_import_controller,
                                commit=commit, allow_regression=allow_regression)
        worker.signals.loaded.connect(lambda seq, result: self._snapshot_loaded(seq, payload, commit, result))
        worker.signals.failed.connect(self._snapshot_failed)
        self._workers.append(worker)
        self._pool.start(worker)

    def _snapshot_loaded(self, generation: int, payload, commit: bool, result: dict):
        if generation != self._generation:
            return
        self._loading = False
        self._workers.clear()
        self.refresh_button.setEnabled(True)
        self.good_import_action.setEnabled(True)
        self.snapshot_button.setEnabled(True)
        if commit:
            self.statusBar().showMessage("Account Snapshot đã nhập · " + result["snapshotId"])
            self.refresh()
            return
        report = result.get("report") or {}
        lines = [f"Nhân vật: {result['characters']}",
                 f"Artifact đang mặc: {result['equippedArtifacts']}",
                 f"Đã chuẩn hóa: {report.get('charactersImported', result['characters'])}"]
        warnings = list(report.get("warnings") or [])
        if warnings:
            lines.extend(["", "Cảnh báo:", *(str(item) for item in warnings[:30])])
        regressions = result.get("abnormalChanges") or []
        if regressions:
            lines.extend(["", "Thay đổi progression giảm:", *(f"{row['characterKey']} {row['field']}: {row['before']} → {row['after']}" for row in regressions[:20])])
        if result.get("duplicate"):
            QMessageBox.information(self, "Account Snapshot", "Snapshot này giống snapshot hiện tại.")
            self.statusBar().showMessage("Snapshot không đổi")
            return
        if QMessageBox.question(self, "Account Snapshot preview", "\n".join(lines) + "\n\nNhập snapshot này?") != QMessageBox.StandardButton.Yes:
            self.statusBar().showMessage("Đã hủy import")
            return
        allow_regression = False
        if regressions:
            answer = QMessageBox.warning(self, "Xác nhận thay đổi progression",
                "Snapshot mới có progression thấp hơn snapshot trước. Vẫn nhập dữ liệu này?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.Cancel,
                QMessageBox.StandardButton.Cancel)
            if answer != QMessageBox.StandardButton.Yes:
                self.statusBar().showMessage("Đã hủy import")
                return
            allow_regression = True
        self._run_snapshot(payload, commit=True, allow_regression=allow_regression)

    def _snapshot_failed(self, generation: int, message: str):
        if generation != self._generation:
            return
        self._loading = False
        self._workers.clear()
        self.refresh_button.setEnabled(True)
        self.good_import_action.setEnabled(True)
        self.snapshot_button.setEnabled(True)
        self.statusBar().showMessage("Account Snapshot chưa được nhập")
        QMessageBox.warning(self, "Account Snapshot", message)

    def import_targets(self):
        if self._loading:
            return
        dialog = TargetContractDialog(self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        try:
            payload = dialog.payload()
        except json.JSONDecodeError as exc:
            QMessageBox.warning(self, "Target JSON", f"JSON không hợp lệ: {exc.msg} (dòng {exc.lineno}).")
            return
        except ValueError as exc:
            QMessageBox.warning(self, "Target JSON", str(exc))
            return
        self._run_target(payload=payload, preview_only=True)

    def import_artifacts(self):
        if self._loading:
            return
        dialog = QDialog(self)
        dialog.setWindowTitle("Xác nhận artifact evaluation")
        dialog.resize(720, 560)
        layout = QVBoxLayout(dialog)
        layout.addWidget(QLabel("Dán AEF JSON từ công cụ đánh giá artifact. Bản preview cho phép chọn từng dòng trước khi ghi."))
        editor = QTextEdit()
        editor.setPlaceholderText('{"format":"AEF","version":1,"evaluations":[...]}')
        layout.addWidget(editor, 1)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok |
                                   QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(dialog.accept); buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        try:
            payload = json.loads(editor.toPlainText())
        except json.JSONDecodeError as exc:
            QMessageBox.warning(self, "Artifact evaluation", f"AEF JSON không hợp lệ: {exc.msg}")
            return
        self._run_artifact(payload)

    def open_logs(self):
        QDesktopServices.openUrl(QUrl.fromLocalFile(self.support_controller.logs_directory()))

    def open_history(self):
        self._run_support("history")

    def _run_plan_runs(self, run_id: str | None = None):
        if self._loading:
            return
        self._loading = True; self._generation += 1
        generation = self._generation; self.runs_button.setEnabled(False)
        self.statusBar().showMessage("Đang replay PlanRun…" if run_id else "Đang tải PlanRun…")
        worker = PlanRunWorker(generation, run_id, self.planner_state_controller)
        worker.signals.loaded.connect(lambda seq, result: self._plan_runs_loaded(seq, result, run_id))
        worker.signals.failed.connect(self._plan_runs_failed)
        self._workers.append(worker); self._pool.start(worker)

    def _plan_runs_loaded(self, generation: int, result, run_id: str | None):
        if generation != self._generation:
            return
        self._loading = False; self._workers.clear(); self.runs_button.setEnabled(True)
        if run_id:
            dialog = QDialog(self); dialog.setWindowTitle("PlanRun replay"); dialog.resize(820, 620)
            layout = QVBoxLayout(dialog)
            view = QTextEdit(); view.setReadOnly(True)
            view.setPlainText(json.dumps(result, ensure_ascii=False, indent=2))
            layout.addWidget(view); dialog.exec(); return
        dialog = PlanRunDialog(result, self)
        if dialog.exec() == QDialog.DialogCode.Accepted and dialog.selected_run():
            self._run_plan_runs(dialog.selected_run())

    def _plan_runs_failed(self, generation: int, message: str):
        if generation != self._generation:
            return
        self._loading = False; self._workers.clear(); self.runs_button.setEnabled(True)
        self.statusBar().showMessage("Không thể đọc PlanRun")
        QMessageBox.warning(self, "PlanRun", message)

    def open_data_health(self):
        self._run_support("health")

    def open_game_data(self):
        if self._loading:
            return
        current = self.game_data_controller.status()
        metadata = current.get("metadata") or {}
        coverage = current.get("coverage") or {}
        account = current.get("accountCoverage") or {}
        message = (
            f"GameData hiện tại: {metadata.get('dataVersion') or 'unknown'} · game {metadata.get('gameVersion') or 'unknown'}\n"
            f"Pack: {coverage.get('characters', 0)} nhân vật · {coverage.get('weapons', 0)} vũ khí · "
            f"{coverage.get('materials', 0)} material\n"
            f"Account: {account.get('knownCharacters', 0)}/{account.get('ownedCharacters', 0)} nhân vật · "
            f"{account.get('knownWeapons', 0)}/{account.get('equippedWeapons', 0)} weapon đang dùng được nhận diện.\n\n"
            "Chọn GameData pack JSON mới để preview/replace."
        )
        if QMessageBox.information(
            self, "GameData local", message,
            QMessageBox.StandardButton.Open | QMessageBox.StandardButton.Cancel,
            QMessageBox.StandardButton.Cancel,
        ) != QMessageBox.StandardButton.Open:
            return
        path, _ = QFileDialog.getOpenFileName(self, "Chọn GameData pack", "", "JSON (*.json);;All files (*)")
        if path:
            self._run_support("gamedata_preview", path)

    def open_settings(self):
        self._run_settings()

    def _run_teams(self, rows: list[dict] | None = None):
        if self._loading:
            return
        self._loading = True; self._generation += 1
        generation = self._generation; self.teams_button.setEnabled(False)
        self.statusBar().showMessage("Đang lưu team…" if rows is not None else "Đang tải team…")
        worker = TeamsWorker(generation, self.teams_controller, rows)
        worker.signals.loaded.connect(lambda seq, result: self._teams_loaded(seq, result, rows is not None))
        worker.signals.failed.connect(self._teams_failed)
        self._workers.append(worker); self._pool.start(worker)

    def _teams_loaded(self, generation: int, result: dict, saving: bool):
        if generation != self._generation:
            return
        self._loading = False; self._workers.clear(); self.teams_button.setEnabled(True)
        if saving:
            self.statusBar().showMessage("Team configuration đã lưu. Đang tính lại…")
            self.refresh(); return
        dialog = TeamsDialog(result, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self._run_teams(dialog.rows())

    def _teams_failed(self, generation: int, message: str):
        if generation != self._generation:
            return
        self._loading = False; self._workers.clear(); self.teams_button.setEnabled(True)
        self.statusBar().showMessage("Team configuration chưa thay đổi")
        QMessageBox.warning(self, "Teams", message)

    def preview_selected_pin(self):
        item = self.character_list.currentItem()
        if item and not self._loading:
            self._run_pin(item.text(), commit=False)

    def _selected_character_key(self) -> str | None:
        item = self.character_list.currentItem()
        return item.text() if item else None

    def open_character_config(self):
        character_key = self._selected_character_key()
        if character_key and not self._loading:
            self._run_character_config(character_key)

    def set_build_intent(self, state: str):
        key = self._selected_character_key()
        if not key or self.build_intent_controller is None:
            return
        try:
            self.build_intent_controller.set_personal_state(key, state)
            self.statusBar().showMessage("Đã cập nhật mục tiêu build. Đang tính lại…")
            self.refresh()
        except Exception as exc:
            log.exception("Could not save personal build intent")
            QMessageBox.warning(self, "Mục tiêu build", str(exc))

    def toggle_wants_build(self):
        key = self._selected_character_key()
        if not key:
            return
        current = ((self._data or {}).get("personalPriorities") or {}).get(key)
        self.set_build_intent("NORMAL" if current == "WANT_BUILD" else "WANT_BUILD")

    def edit_selected_artifact_rv(self):
        key = self._selected_character_key()
        if not key or not self._data:
            return
        rows = self._data.get("characters", [])
        characters = {}
        selected_row = None
        for row in rows:
            weapon = row.get("weapon")
            artifacts = {}
            for artifact in row.get("artifacts", []):
                value = {"setKey": artifact.get("set"), "rv": artifact.get("rv"),
                         "level": artifact.get("level", 20), "mainStat": artifact.get("mainStat")}
                artifacts[artifact["slot"]] = value
            characters[row["key"]] = {
                "level": row["level"], "ascension": row["ascension"], "constellation": row.get("constellation", 0),
                "weapon": ({"key": weapon["key"], "level": weapon["level"], "ascension": weapon.get("ascension", 0),
                            "refinement": weapon.get("refinement", 1)} if weapon else None),
                "talents": row["talents"], "artifacts": artifacts,
            }
            if row["key"] == key:
                selected_row = row
        if selected_row is None:
            return
        dialog = SnapshotEditorDialog(self)
        dialog.editor.setPlainText(json.dumps({"version": 1, "characters": characters}, ensure_ascii=False, indent=2))
        dialog.manual_key.setText(key)
        dialog.manual_level.setValue(min(100, max(1, int(selected_row.get("level", 1)))))
        dialog.manual_ascension.setValue(int(selected_row.get("ascension", 0)))
        dialog.manual_constellation.setValue(int(selected_row.get("constellation", 0)))
        for name, spin in dialog.manual_talents.items():
            spin.setValue(int(selected_row.get("talents", {}).get({"normal": "normal", "skill": "skill", "burst": "burst"}[name], 1)))
        weapon = selected_row.get("weapon")
        if weapon:
            dialog.manual_weapon.setText(weapon["key"])
            dialog.manual_weapon_level.setValue(weapon["level"])
            dialog.manual_weapon_ascension.setValue(int(weapon.get("ascension", 0)))
        for artifact in selected_row.get("artifacts", []):
            fields = dialog.manual_artifacts.get(artifact["slot"])
            if not fields:
                continue
            set_box, main_stat, known, rv, level = fields
            set_box.setText(artifact.get("set") or "")
            if main_stat:
                main_stat.setText(artifact.get("mainStat") or "")
            level.setValue(int(artifact.get("level", 20)))
            if artifact.get("rv") is not None:
                known.setChecked(True)
                rv.setValue(float(artifact["rv"]))
        dialog.tabs.setCurrentIndex(1)
        dialog.setWindowTitle(f"Điền RV · {key}")
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        self._snapshot_payload = dialog.payload()
        self._run_snapshot(self._snapshot_payload, commit=False)

    def open_theater_preparation(self):
        if self.build_intent_controller is None:
            return
        data = self._data or {}
        config = ((data.get("roadmap") or {}).get("theaterPreparation") or {}).get("config") or {}
        dialog = QDialog(self)
        dialog.setWindowTitle("Chuẩn bị Nhà Hát Imaginarium")
        layout = QVBoxLayout(dialog)
        layout.addWidget(QLabel("Chọn đúng ba nguyên tố. Engine ưu tiên nhân vật đã đạt tiêu chuẩn build."))
        elements = sorted({row.get("element") for row in data.get("characters", []) if row.get("element")})
        checks = []
        for element in elements:
            box = QCheckBox(element)
            box.setChecked(element in config.get("elements", []))
            checks.append(box)
            layout.addWidget(box)
        form = QFormLayout()
        count = QSpinBox(); count.setRange(1, 100); count.setValue(int(config.get("requiredCharacters", 4)))
        form.addRow("Số nhân vật cần chuẩn bị", count)
        layout.addLayout(form)
        layout.addWidget(QLabel("Bạn có thể chọn nhân vật cụ thể; để trống danh sách thì engine tự đề xuất."))
        roster = QListWidget()
        roadmap_theater = ((data.get("roadmap") or {}).get("theaterPreparation") or {})
        selected = (set(config.get("selectedCharacters", [])) if config.get("manualSelection", bool(config.get("selectedCharacters")))
                    else set(roadmap_theater.get("selectedKeys", [])))
        roster_selection_changed = [False]
        ready = sum(1 for row in roadmap_theater.get("readiness", {}).values()
                    if row.get("status") == "READY")
        roster_summary = QLabel()
        layout.addWidget(roster_summary)
        def rebuild_roster(*_):
            selected.update(roster.item(i).text() for i in range(roster.count())
                            if roster.item(i).checkState() == Qt.CheckState.Checked)
            roster.clear()
            chosen = {box.text() for box in checks if box.isChecked()}
            matching = [row for row in data.get("characters", []) if row.get("element") in chosen]
            proposal = (set(config.get("selectedCharacters", [])) if config.get("manualSelection", bool(config.get("selectedCharacters")))
                        else set(roadmap_theater.get("selectedKeys", [])))
            ready_count = sum(1 for key in proposal
                              if (roadmap_theater.get("readiness", {}).get(key) or {}).get("status") == "READY")
            roster_summary.setText(
                f"Đề xuất: {len(proposal)}/{count.value()} · Đạt chuẩn: {ready_count}/{count.value()} · "
                f"Nhân vật thuộc nguyên tố đã chọn: {len(matching)}")
            for row in matching:
                item = QListWidgetItem(row["key"])
                item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
                item.setCheckState(Qt.CheckState.Checked if row["key"] in selected else Qt.CheckState.Unchecked)
                status = roadmap_theater.get("readiness", {}).get(row["key"], {})
                details = "; ".join(status.get("missing", [])) or "Đạt tiêu chuẩn build đã biết"
                item.setToolTip(f"{status.get('status', 'UNKNOWN')}: {details}")
                roster.addItem(item)
        roster.itemChanged.connect(lambda _item: roster_selection_changed.__setitem__(0, True))
        for box in checks:
            box.toggled.connect(rebuild_roster)
        count.valueChanged.connect(rebuild_roster)
        rebuild_roster()
        layout.addWidget(roster)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(dialog.accept); buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        chosen_elements = [box.text() for box in checks if box.isChecked()]
        selected_keys = [roster.item(i).text() for i in range(roster.count())
                         if roster.item(i).checkState() == Qt.CheckState.Checked]
        try:
            self.build_intent_controller.save_theater({
                "elements": chosen_elements, "requiredCharacters": count.value(),
                "selectedCharacters": selected_keys,
                "manualSelection": roster_selection_changed[0] or bool(config.get("manualSelection", bool(config.get("selectedCharacters")))),
                "excludedCharacters": config.get("excludedCharacters", []),
            })
            self.refresh()
        except Exception as exc:
            log.exception("Could not save Theater preparation")
            QMessageBox.warning(self, "Chuẩn bị Nhà Hát", str(exc))

    def open_target_editor(self):
        if self._loading or not self._data:
            return
        characters = self._data.get("characters") or []
        if not characters:
            QMessageBox.information(self, "Target", "Import GOOD trước để tải danh sách nhân vật.")
            return
        selected_key = self._selected_character_key()
        if not selected_key:
            selected_key = characters[0].get("key")
        dialog = TargetEditorDialog(characters, selected_key, self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        try:
            payload = dialog.payload()
        except ValueError as exc:
            QMessageBox.information(self, "Target", str(exc))
            return
        self._run_target(payload=payload, preview_only=True)

    def _run_character_config(self, character_key: str, payload: dict | None = None):
        if self._loading:
            return
        self._loading = True; self._generation += 1
        generation = self._generation
        for button in (self.character_config_button, self.create_preset_action,
                       self.activate_preset_action, self.pin_button, self.unpin_action):
            button.setEnabled(False)
        self.statusBar().showMessage("Đang lưu cấu hình nhân vật…" if payload else "Đang tải cấu hình nhân vật…")
        worker = CharacterConfigWorker(generation, self.character_configuration_controller,
                                       character_key, payload)
        worker.signals.loaded.connect(
            lambda seq, result: self._character_config_loaded(seq, character_key, result, payload is not None))
        worker.signals.failed.connect(self._character_config_failed)
        self._workers.append(worker); self._pool.start(worker)

    def _character_config_loaded(self, generation: int, character_key: str, result: dict, saving: bool):
        if generation != self._generation:
            return
        self._loading = False; self._workers.clear()
        for button in (self.character_config_button, self.create_preset_action,
                       self.activate_preset_action, self.pin_button, self.unpin_action):
            button.setEnabled(True)
        if saving:
            self.statusBar().showMessage("Tier / priority đã lưu. Đang tính lại…")
            self.refresh(); return
        dialog = CharacterConfigDialog(result, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self._run_character_config(character_key, dialog.payload())

    def _character_config_failed(self, generation: int, message: str):
        if generation != self._generation:
            return
        self._loading = False; self._workers.clear()
        for button in (self.character_config_button, self.create_preset_action,
                       self.activate_preset_action, self.pin_button, self.unpin_action):
            button.setEnabled(True)
        self.statusBar().showMessage("Cấu hình nhân vật chưa thay đổi")
        QMessageBox.warning(self, "Character configuration", message)

    def create_selected_preset(self):
        character_key = self._selected_character_key()
        if not character_key or self._loading:
            return
        label, ok = QInputDialog.getText(self, "Tạo target preset",
                                         f"Tên preset mới cho {character_key}:")
        label = label.strip()
        if ok and label:
            self._run_target_preset(character_key, create_label=label)

    def activate_selected_preset(self):
        character_key = self._selected_character_key()
        if not character_key or self._loading or not self._data:
            return
        row = next((item for item in self._data.get("characters", [])
                    if item["key"] == character_key), None)
        presets = (row or {}).get("presets") or []
        if not presets:
            QMessageBox.information(self, "Target preset", "Nhân vật này chưa có target preset.")
            return
        labels = [f"{item['label']} ({item['key']})" + (" · active" if item.get("active") else "")
                  for item in presets]
        selected, ok = QInputDialog.getItem(self, "Đổi target preset",
                                             f"Preset active cho {character_key}:",
                                             labels, 0, False)
        if not ok:
            return
        index = labels.index(selected)
        preset = presets[index]
        if preset.get("active"):
            self.statusBar().showMessage("Preset này đang active.")
            return
        self._run_target_preset(character_key, activate_key=preset["key"])

    def _run_target_preset(self, character_key: str, *, create_label: str | None = None,
                           activate_key: str | None = None):
        if self._loading:
            return
        self._loading = True; self._generation += 1
        generation = self._generation
        for button in (self.character_config_button, self.create_preset_action,
                       self.activate_preset_action, self.pin_button, self.unpin_action):
            button.setEnabled(False)
        self.statusBar().showMessage("Đang cập nhật target preset…")
        worker = TargetPresetWorker(generation, character_key, self.target_controller,
                                    create_label=create_label, activate_key=activate_key)
        worker.signals.loaded.connect(self._target_preset_loaded)
        worker.signals.failed.connect(self._target_preset_failed)
        self._workers.append(worker); self._pool.start(worker)

    def _target_preset_loaded(self, generation: int, result: dict):
        if generation != self._generation:
            return
        self._loading = False; self._workers.clear()
        for button in (self.character_config_button, self.create_preset_action,
                       self.activate_preset_action, self.pin_button, self.unpin_action):
            button.setEnabled(True)
        self.statusBar().showMessage("Target preset đã cập nhật. Đang tính lại…")
        self.refresh()

    def _target_preset_failed(self, generation: int, message: str):
        if generation != self._generation:
            return
        self._loading = False; self._workers.clear()
        for button in (self.character_config_button, self.create_preset_action,
                       self.activate_preset_action, self.pin_button, self.unpin_action):
            button.setEnabled(True)
        self.statusBar().showMessage("Target preset chưa thay đổi")
        QMessageBox.warning(self, "Target preset", message)

    def _run_pin(self, character_key: str | None, *, commit: bool):
        if self._loading:
            return
        self._loading = True; self._generation += 1
        generation = self._generation
        self.pin_button.setEnabled(False); self.unpin_action.setEnabled(False)
        self.statusBar().showMessage("Đang lưu pin…" if commit else "Đang kiểm tra allocation conflict…")
        worker = PinWorker(generation, character_key, commit, self.planner_state_controller)
        worker.signals.loaded.connect(
            lambda seq, result: self._pin_loaded(seq, result, character_key, commit))
        worker.signals.failed.connect(self._pin_failed)
        self._workers.append(worker); self._pool.start(worker)

    def _pin_loaded(self, generation: int, result: dict, character_key: str | None, commit: bool):
        if generation != self._generation:
            return
        self._loading = False; self._workers.clear()
        self.pin_button.setEnabled(True); self.unpin_action.setEnabled(True)
        if commit:
            self.statusBar().showMessage("Đã cập nhật pin Today. Đang tính lại…")
            self.refresh(); return
        conflicts = result["conflicts"]
        lines = [f"Pin {character_key} chỉ thay đổi lựa chọn Today.",
                 "Global Plan, tier và priority override vẫn giữ nguyên."]
        if result["candidate"]:
            lines.append("Task được đề xuất: " + result["candidate"]["title"])
        else:
            lines.append("Nhân vật hiện không có task khả dụng; pin vẫn được giữ để chờ target/data.")
        if conflicts:
            lines.append("\nALLOCATION CONFLICT:")
            lines.extend(f"{item['materialKey']}: strategic {item['strategicRequired']} + pin {item['pinnedRequired']} > available {item['available']}"
                         for item in conflicts)
        decision = QMessageBox.warning(self, "Allocation Conflict Preview", "\n".join(lines),
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.Cancel,
            QMessageBox.StandardButton.Cancel)
        if decision == QMessageBox.StandardButton.Yes:
            self._run_pin(character_key, commit=True)

    def _pin_failed(self, generation: int, message: str):
        if generation != self._generation:
            return
        self._loading = False; self._workers.clear()
        self.pin_button.setEnabled(True); self.unpin_action.setEnabled(True)
        self.statusBar().showMessage("Pin Today chưa thay đổi")
        QMessageBox.warning(self, "Pin Today", message)

    def _run_settings(self, payload: dict | None = None):
        if self._loading:
            return
        self._loading = True
        self._generation += 1
        generation = self._generation
        self.settings_button.setEnabled(False); self.refresh_button.setEnabled(False)
        self.statusBar().showMessage("Đang lưu settings…" if payload else "Đang tải settings…")
        worker = SettingsWorker(generation, self.settings_controller, payload)
        worker.signals.loaded.connect(lambda seq, result: self._settings_loaded(seq, result, payload is not None))
        worker.signals.failed.connect(self._settings_failed)
        self._workers.append(worker); self._pool.start(worker)

    def _settings_loaded(self, generation: int, result: dict, saving: bool):
        if generation != self._generation:
            return
        self._loading = False; self._workers.clear()
        self.settings_button.setEnabled(True); self.refresh_button.setEnabled(True)
        if saving:
            self.statusBar().showMessage("Settings đã lưu. Đang tính lại kế hoạch…")
            self.refresh()
            return
        dialog = SettingsDialog(result, self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            self.statusBar().showMessage("Đã hủy thay đổi settings")
            return
        try:
            payload = dialog.payload()
        except ValueError as exc:
            QMessageBox.warning(self, "Settings", str(exc))
            return
        self._run_settings(payload)

    def _settings_failed(self, generation: int, message: str):
        if generation != self._generation:
            return
        self._loading = False; self._workers.clear()
        self.settings_button.setEnabled(True); self.refresh_button.setEnabled(True)
        self.statusBar().showMessage("Settings chưa được thay đổi")
        QMessageBox.warning(self, "Settings", message)

    def export_backup(self):
        path, _ = QFileDialog.getSaveFileName(self, "Xuất backup", "GenshinPlanner-backup.zip",
                                               "ZIP backup (*.zip)")
        if path:
            self._run_support("backup", path)

    def restore_backup(self):
        path, _ = QFileDialog.getOpenFileName(self, "Khôi phục backup", "", "ZIP backup (*.zip)")
        if not path:
            return
        result = QMessageBox.warning(self, "Khôi phục backup",
                                     "Dữ liệu local hiện tại sẽ được thay bằng backup đã chọn. Một backup trước restore sẽ được tạo tự động.",
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.Cancel,
                                     QMessageBox.StandardButton.Cancel)
        if result == QMessageBox.StandardButton.Yes:
            self._run_support("restore", path)

    def _run_support(self, action: str, value: object = None):
        if self._loading:
            return
        self._loading = True
        self._generation += 1
        generation = self._generation
        for button in (self.refresh_button, self.good_import_action, self.target_button,
                       self.artifact_button, self.history_button, self.health_button,
                       self.backup_button, self.restore_button):
            button.setEnabled(False)
        self.statusBar().showMessage("Đang xử lý…")
        worker = SupportWorker(generation, action, value, self.game_data_controller,
                               self.support_controller)
        worker.signals.loaded.connect(lambda seq, result: self._support_loaded(seq, action, result))
        worker.signals.failed.connect(self._support_failed)
        self._workers.append(worker)
        self._pool.start(worker)

    def _support_loaded(self, generation: int, action: str, result):
        if generation != self._generation:
            return
        self._loading = False
        self._workers.clear()
        for button in (self.refresh_button, self.good_import_action, self.target_button,
                       self.artifact_button, self.history_button, self.health_button,
                       self.backup_button, self.restore_button):
            button.setEnabled(True)
        if action == "history":
            dialog = HistoryDialog(result, self)
            if dialog.exec() == QDialog.DialogCode.Accepted:
                pair = dialog.selected_pair()
                if pair and pair[0] != pair[1]:
                    self._run_support("history_compare", pair)
        elif action == "history_compare":
            summary = result.get("summary", {})
            lines = [
                f"Tổng thay đổi: {summary.get('totalChanges', 0)}",
                f"Nhân vật lên level: {summary.get('charactersLeveled', 0)}",
                f"Talent tăng: {summary.get('talentsUpgraded', 0)}",
                f"Weapon tăng: {summary.get('weaponsUpgraded', 0)}",
                f"Artifact loadout đổi: {summary.get('artifactLoadoutsChanged', 0)}",
                "",
            ]
            for change in result.get("changes", []):
                character = change.get("characterKey")
                prefix = f"{character} · " if character else ""
                lines.append(prefix + str(change.get("eventType", "CHANGE")))
            dialog = QDialog(self)
            dialog.setWindowTitle("So sánh snapshot")
            dialog.resize(760, 560)
            layout = QVBoxLayout(dialog)
            view = QTextEdit(); view.setReadOnly(True); view.setPlainText("\n".join(lines))
            layout.addWidget(view)
            close = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
            close.rejected.connect(dialog.reject); layout.addWidget(close)
            dialog.exec()
        elif action == "health":
            lines = [f"Trạng thái: {result['status']}",
                     f"Lỗi: {result['counts']['errors']} · Cảnh báo: {result['counts']['warnings']} · Thông tin: {result['counts']['info']}", ""]
            for issue in result["issues"]:
                lines.append(f"[{issue['severity']}] {issue['code']} ×{issue['count']}")
                lines.append(f"  Ảnh hưởng quyết định: {issue.get('decisionImpact', 'Chưa xác định')}")
                lines.append(f"  Hành động: {issue['action']}")
                if issue.get("details"):
                    lines.append("  Chi tiết: " + json.dumps(issue["details"], ensure_ascii=False))
            dialog = QDialog(self)
            dialog.setWindowTitle("Data Health")
            dialog.resize(760, 560)
            layout = QVBoxLayout(dialog)
            view = QTextEdit(); view.setReadOnly(True); view.setPlainText("\n".join(lines))
            layout.addWidget(view)
            dialog.exec()
        elif action == "gamedata_preview":
            meta = result.get("metadata") or {}
            cov = result.get("coverage") or {}
            acc = result.get("accountCoverage") or {}
            missing_chars = acc.get("missingCharacters") or []
            missing_weapons = acc.get("missingWeapons") or []
            lines = [
                f"Data version: {meta.get('dataVersion') or 'unknown'}",
                f"Game version: {meta.get('gameVersion') or 'unknown'}",
                f"Characters: {cov.get('characters', 0)} · Weapons: {cov.get('weapons', 0)} · Materials: {cov.get('materials', 0)}",
                f"Account coverage: {acc.get('knownCharacters', 0)}/{acc.get('ownedCharacters', 0)} characters · "
                f"{acc.get('knownWeapons', 0)}/{acc.get('equippedWeapons', 0)} equipped weapons",
            ]
            if missing_chars:
                lines.append("Thiếu character: " + ", ".join(missing_chars))
            if missing_weapons:
                lines.append("Thiếu weapon: " + ", ".join(missing_weapons))
            lines.append("\nPack hợp lệ. Cài đặt pack này? Pack hiện tại sẽ được backup trước khi replace.")
            if QMessageBox.question(
                self, "GameData preview", "\n".join(lines),
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.Cancel,
                QMessageBox.StandardButton.Cancel,
            ) == QMessageBox.StandardButton.Yes:
                self._run_support("gamedata_install", result["path"])
        elif action == "gamedata_install":
            meta = result.get("metadata") or {}
            account = result.get("accountCoverage") or {}
            QMessageBox.information(
                self, "GameData",
                f"Đã cài GameData {meta.get('dataVersion') or 'unknown'}.\n"
                f"Coverage account: {account.get('knownCharacters', 0)}/{account.get('ownedCharacters', 0)} characters.\n"
                f"Backup pack cũ: {result.get('backupPath') or 'không có'}",
            )
            self.refresh()
            return
        elif action == "gamedata_export":
            QMessageBox.information(self, "GameData", "Đã xuất pack:\n" + str(result.get("path")))
        elif action == "backup":
            self.statusBar().showMessage("Đã xuất backup: " + result["path"])
        elif action == "restore":
            self.statusBar().showMessage("Đã restore backup. Đang tính lại kế hoạch…")
            self.refresh()

    def _support_failed(self, generation: int, message: str):
        if generation != self._generation:
            return
        self._loading = False
        self._workers.clear()
        for button in (self.refresh_button, self.good_import_action, self.target_button,
                       self.artifact_button, self.history_button, self.health_button,
                       self.backup_button, self.restore_button):
            button.setEnabled(True)
        self.statusBar().showMessage("Thao tác không hoàn tất; dữ liệu hiện tại vẫn được giữ")
        QMessageBox.warning(self, "Genshin Planner", message)

    def _run_target(self, *, path: str | None = None, payload: object = None,
                    selected: set[str] | None = None, operation_id: str | None = None,
                    preview_only: bool = False):
        if self._loading:
            return
        self._loading = True
        self._generation += 1
        generation = self._generation
        self.refresh_button.setEnabled(False)
        self.good_import_action.setEnabled(False)
        self.target_button.setEnabled(False)
        self.artifact_button.setEnabled(False)
        self.statusBar().showMessage("Đang kiểm tra Target JSON…" if path or preview_only else "Đang lưu target…")
        worker = TargetWorker(generation, path=path, payload=payload,
                              selected=selected, operation_id=operation_id,
                              preview_only=preview_only, controller=self.target_controller)
        worker.signals.loaded.connect(lambda seq, result: self._target_loaded(
            seq, result, path=path, preview_only=preview_only))
        worker.signals.failed.connect(self._target_failed)
        self._workers.append(worker)
        self._pool.start(worker)

    def _target_loaded(self, generation: int, result: dict, *, path: str | None,
                       preview_only: bool = False):
        if generation != self._generation:
            return
        self._loading = False
        self._workers.clear()
        self.refresh_button.setEnabled(True)
        self.good_import_action.setEnabled(True)
        self.target_button.setEnabled(True)
        self.artifact_button.setEnabled(True)
        if path is None and not preview_only:
            saved = result.get("saved", [])
            details = [f"Đã commit {len(saved)} target."]
            if saved:
                details.append("Đã lưu: " + ", ".join(item["characterKey"] for item in saved))
            if result.get("invalidTargets"):
                details.append(f"Giữ nguyên {len(result['invalidTargets'])} target lỗi.")
            if result.get("unknownCharacters"):
                details.append(f"Giữ nguyên {len(result['unknownCharacters'])} nhân vật không thuộc account.")
            self.statusBar().showMessage(f"Đã lưu {len(saved)} target")
            QMessageBox.information(self, "Target JSON", "\n".join(details))
            self.refresh()
            return
        preview = result["preview"]
        dialog = TargetSelectionDialog(preview, self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            self.statusBar().showMessage("Đã hủy Target import")
            return
        selected = dialog.selected_keys()
        if not selected:
            self.statusBar().showMessage("Chưa chọn target hợp lệ")
            return
        self._run_target(payload=result["payload"], selected=selected,
                         operation_id=str(uuid4()))

    def _target_failed(self, generation: int, message: str):
        if generation != self._generation:
            return
        self._loading = False
        self._workers.clear()
        self.refresh_button.setEnabled(True)
        self.good_import_action.setEnabled(True)
        self.target_button.setEnabled(True)
        self.artifact_button.setEnabled(True)
        self.statusBar().showMessage("Target import chưa thực hiện")
        QMessageBox.warning(self, "Target JSON", message)

    def _run_artifact(self, payload: object, *, snapshot_id: str | None = None,
                      rows: list[dict] | None = None):
        if self._loading:
            return
        self._loading = True
        self._generation += 1
        generation = self._generation
        for button in (self.refresh_button, self.good_import_action, self.target_button,
                       self.artifact_button):
            button.setEnabled(False)
        self.statusBar().showMessage("Đang xác nhận artifact…" if rows is not None else "Đang kiểm tra artifact…")
        worker = ArtifactWorker(generation, payload, snapshot_id=snapshot_id, rows=rows,
                                controller=self.artifact_exchange_controller)
        worker.signals.loaded.connect(
            lambda seq, result: self._artifact_loaded(seq, result, confirming=rows is not None))
        worker.signals.failed.connect(self._artifact_failed)
        self._workers.append(worker)
        self._pool.start(worker)

    def _artifact_loaded(self, generation: int, result: dict, *, confirming: bool):
        if generation != self._generation:
            return
        self._loading = False
        self._workers.clear()
        for button in (self.refresh_button, self.good_import_action, self.target_button,
                       self.artifact_button):
            button.setEnabled(True)
        if confirming:
            self.statusBar().showMessage(f"Đã xác nhận {len(result['evaluations'])} artifact evaluation. Đang tính lại…")
            self.refresh()
            return
        dialog = ArtifactSelectionDialog(result, self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            self.statusBar().showMessage("Đã hủy artifact evaluation")
            return
        rows = dialog.selected_rows()
        if not rows:
            self.statusBar().showMessage("Chưa chọn artifact evaluation hợp lệ")
            return
        self._run_artifact(None, snapshot_id=result["snapshotId"], rows=rows)

    def _artifact_failed(self, generation: int, message: str):
        if generation != self._generation:
            return
        self._loading = False
        self._workers.clear()
        for button in (self.refresh_button, self.good_import_action, self.target_button,
                       self.artifact_button):
            button.setEnabled(True)
        self.statusBar().showMessage("Artifact evaluation chưa được ghi")
        QMessageBox.warning(self, "Artifact evaluation", message)

    def _run_good(self, path: str, *, commit: bool, allow_regression: bool = False):
        if self._loading:
            return
        self._loading = True
        self._generation += 1
        generation = self._generation
        self.refresh_button.setEnabled(False)
        self.snapshot_button.setEnabled(False)
        self.good_import_action.setEnabled(False)
        self.target_button.setEnabled(False)
        self.statusBar().showMessage("Đang import GOOD…" if commit else "Đang kiểm tra GOOD…")
        worker = GoodWorker(generation, path, self.account_import_controller, commit, allow_regression)
        worker.signals.loaded.connect(lambda seq, result: self._good_loaded(seq, path, commit, result))
        worker.signals.failed.connect(self._good_failed)
        self._workers.append(worker)
        self._pool.start(worker)

    def _good_loaded(self, generation: int, path: str, commit: bool, result: dict):
        if generation != self._generation:
            return
        self._loading = False
        self._workers.clear()
        self.refresh_button.setEnabled(True)
        self.snapshot_button.setEnabled(True)
        self.good_import_action.setEnabled(True)
        self.target_button.setEnabled(True)
        if commit:
            self.statusBar().showMessage("GOOD import thành công · " + result["snapshotId"])
            self.refresh()
            return
        if result["duplicate"]:
            QMessageBox.information(self, "GOOD preview", "Snapshot này giống snapshot hiện tại.")
            self.statusBar().showMessage("Snapshot không đổi")
            return
        lines = [f"Nhân vật: {result['characters']}", f"Weapon: {result['weapons']}",
                 f"Artifact đang mặc: {result['equippedArtifacts']}", f"Team: {result['teams']}",
                 "", "Coverage:"]
        lines.extend(f"• {key}: {value}" for key, value in result["coverage"].items())
        if result["warnings"]:
            lines.extend(["", "Cảnh báo:", *(str(item) for item in result["warnings"])])
        regressions = result["abnormalChanges"]
        if regressions:
            lines.extend(["", "GIẢM BẤT THƯỜNG:", *(f"{item['characterKey']} {item['field']}: {item['before']} → {item['after']}"
                                                    for item in regressions)])
        decision = QMessageBox.question(self, "GOOD preview", "\n".join(lines) + "\n\nImport snapshot này?")
        if decision == QMessageBox.StandardButton.Yes:
            allow_regression = False
            if regressions:
                override = QMessageBox.warning(
                    self, "Xác nhận giảm progression",
                    "GOOD mới có level/talent thấp hơn snapshot hiện tại. Vẫn import và ghi nhận thay đổi này?",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.Cancel,
                    QMessageBox.StandardButton.Cancel)
                if override != QMessageBox.StandardButton.Yes:
                    self.statusBar().showMessage("Đã hủy import")
                    return
                allow_regression = True
            self._run_good(path, commit=True, allow_regression=allow_regression)
        else:
            self.statusBar().showMessage("Đã hủy import")

    def _good_failed(self, generation: int, message: str):
        if generation != self._generation:
            return
        self._loading = False
        self._workers.clear()
        self.refresh_button.setEnabled(True)
        self.snapshot_button.setEnabled(True)
        self.good_import_action.setEnabled(True)
        self.target_button.setEnabled(True)
        self.statusBar().showMessage("GOOD import chưa thực hiện")
        QMessageBox.warning(self, "GOOD import", message)

    def _render_today(self, data):
        self.today_action.show()
        self.today_avatar.show()
        self.today_import_button.hide()
        for label in (self.today_badge, self.today_avail_badge, self.today_resin_badge):
            set_state(label, "")
        plan = data["today"]
        if plan is None:
            self.today_setup_target.setVisible(False)
            self._primary_today_task = None
            self.today_title.setText("Chưa có tài khoản nào được nhập")
            self.today_import_button.show()
            self.today_import_button.setEnabled(not self._loading)
            self.today_action.setText("Nhập Account Snapshot hoặc file GOOD để xem kế hoạch nâng cấp.")
            self.today_why.setText("")
            self.today_badge.setText("CHƯA CÓ SNAPSHOT")
            self.today_avatar.setPixmap(self.style().standardIcon(QStyle.StandardPixmap.SP_MessageBoxInformation).pixmap(48, 48))
            self.today_resin_badge.setText("Nhựa: chưa có dữ liệu")
            self.today_avail_badge.setText("Khả dụng: chưa có dữ liệu")
            self.today_source_label.setText("Nguồn dữ liệu: chưa có snapshot")
            self.today_material_table.setRowCount(0)
            self.today_meta_info.setText("Chưa có dữ liệu.")
            self.today_alternatives_list.clear()
            self.today_context.clear()
            return

        all_tasks = [*plan["quickActions"], *plan["farming"],
                     *plan["unavailable"], *plan["blocked"]]
        task = plan.get("primaryTask")

        if task is None:
            self._primary_today_task = None
            reason = plan.get("noActionReason") or "NO_STRATEGIC_GOAL"
            missing_targets = int((plan.get("coverage") or {}).get("missingTargets") or 0)
            missing_profiles = int((plan.get("coverage") or {}).get("missingProfiles") or 0)
            knowledge_ready = bool((plan.get("coverage") or {}).get("buildKnowledgeReady", True))
            needs_target = reason == "NO_STRATEGIC_GOAL" and missing_targets > 0
            needs_knowledge = reason == "NO_STRATEGIC_GOAL" and (missing_profiles > 0 or not knowledge_ready)
            messages = {
                "PINNED_CHARACTER_NO_TASK": "Nhân vật đang ghim chưa có việc trực tiếp có thể đề xuất.",
                "STRATEGIC_CHARACTER_NO_TASK": "Ưu tiên chiến lược hiện tại chưa có việc trực tiếp có thể đề xuất.",
                "NO_STRATEGIC_GOAL": (f"{missing_targets} nhân vật chưa có dữ liệu trạng thái đầy đủ. Cập nhật snapshot để phân tích."
                                       if needs_target else f"Knowledge Base chưa có profile build đã duyệt cho {missing_profiles} nhân vật. Cần cập nhật Build Pack để tạo roadmap."
                                       if needs_knowledge else "Các mục tiêu hiện tại không còn việc progression cần thực hiện."),
            }
            unranked = [row["key"] for row in data.get("characters", []) if row.get("tierScore") is None]
            self.today_title.setText("Chưa xếp tier" if unranked and not needs_knowledge else
                                     "Đang thiếu build knowledge" if needs_knowledge else "Không có việc trực tiếp cho ưu tiên hiện tại")
            self.today_action.setText(f"Hãy chấm tier cho {len(unranked)} nhân vật sở hữu để tạo roadmap."
                                      if unranked and not needs_knowledge else messages.get(reason, "Chưa có hành động trực tiếp."))
            self.today_why.setText("Mục tiêu không có việc còn thiếu sẽ tự được loại khỏi kế hoạch." if not needs_target else "")
            self.today_setup_target.setVisible(False)
            self.today_badge.setText("CHƯA CÓ HÀNH ĐỘNG")
            self.today_avatar.setPixmap(self.style().standardIcon(QStyle.StandardPixmap.SP_MessageBoxInformation).pixmap(48, 48))
            self.today_resin_badge.setText("Nhựa: chưa có dữ liệu")
            self.today_avail_badge.setText("Khả dụng: chưa có dữ liệu")
            self.today_source_label.setText("")
            self.today_material_table.setRowCount(0)

            # Alternatives
            self.today_alternatives_list.clear()
            alternatives = plan.get("alternativeTasks") or []
            for alt in alternatives:
                item = QListWidgetItem(f"• {alt.get('title', alt.get('id', 'task'))}")
                self.today_alternatives_list.addItem(item)

            meta_lines = [f"Nhân vật có profile build: {int((plan.get('coverage') or {}).get('configuredTargets') or 0)}"]
            self.today_meta_info.setText("\n".join(meta_lines))
            self.today_context.setPlainText("\n".join(meta_lines))
            theater = ((data.get("roadmap") or {}).get("theaterPreparation") or {})
            config = theater.get("config") or {}
            if config.get("elements"):
                ready = sum(1 for key in theater.get("selectedKeys", [])
                            if (theater.get("readiness", {}).get(key) or {}).get("status") == "READY")
                self.today_context.append(
                    f"Chuẩn bị Nhà Hát: {ready}/{int(config.get('requiredCharacters', 0))} nhân vật đạt chuẩn build đã biết.")
            return

        self._primary_today_task = task
        self.today_setup_target.setVisible(False)

        char_name = task.get("character", {}).get("name") if task.get("character") else task.get("character", {}).get("key")
        char_key = task.get("character", {}).get("key") or char_name or ""
        self.today_avatar.setPixmap(get_character_pixmap(char_key, 76))
        self.today_avatar.setVisible(bool(char_key))

        title_text = task.get("title") or "Hành động đề xuất"
        self.today_title.setText(title_text)

        action_text = task.get("actionText") or task.get("summary") or title_text
        why_summary = task.get("whySummary") or "Theo thứ tự ưu tiên chiến lược hiện tại."

        action_parts = dict.fromkeys(value for value in (title_text, action_text)
                                    if value and value != self.today_title.text())
        self.today_action.setText(" · ".join(action_parts))
        self.today_action.setVisible(bool(action_parts))
        self.today_why.setText(f"Vì sao: {why_summary} (Điểm ưu tiên: {task.get('score', 0):.1f})")

        # Action Badge
        self.today_badge.setText("ĐỀ XUẤT")
        self.today_badge.setObjectName("badge")
        set_state(self.today_badge, "accent")

        # Resin & Availability Badges
        source = task.get("source") or {}
        resin_cost = source.get("resinCost", source.get("resin_cost"))
        resin_avail = source.get("resinAvailable")
        if resin_cost is not None:
            resin_str = f"Nhựa: {resin_cost}/lần"
            if resin_avail is not None:
                resin_str += f" · Đang có {resin_avail}"
            self.today_resin_badge.setText(resin_str)
            self.today_resin_badge.setVisible(True)
        else:
            self.today_resin_badge.setText("Nhựa: theo nguồn thực hiện")

        avail_labels = {
            "AVAILABLE": "Có thể theo đuổi",
            "PREREQUISITE_BLOCKED": "Cần hoàn thành bước tiên quyết",
            "ALWAYS_AVAILABLE": "Luôn khả dụng",
            "UNAVAILABLE_TODAY": "Chưa mở hôm nay",
            "WEEKLY_LIMITED": "Giới hạn tuần",
        }
        avail_str = avail_labels.get(task.get("availability"), task.get("availability") or "-")
        self.today_avail_badge.setText(avail_str)
        if task.get("availability") in {"UNAVAILABLE_TODAY", "PREREQUISITE_BLOCKED"}:
            self.today_avail_badge.setObjectName("fact")
            set_state(self.today_avail_badge, "warning")
        elif task.get("availability") in {"AVAILABLE", "ALWAYS_AVAILABLE"}:
            self.today_avail_badge.setObjectName("fact")
            set_state(self.today_avail_badge, "success")

        source_name = source.get("name") or source.get("key") or ""
        if task.get("availableWeekdays"):
            source_name += f" ({', '.join(task['availableWeekdays'])})"
        methods = task.get("farmMethods") or []
        method_names = list(dict.fromkeys((method.get("source") or {}).get("name")
                                         for method in methods if (method.get("source") or {}).get("name")))
        self.today_source_label.setText(" · ".join(method_names) or source_name)

        # Populate Materials Table
        resources = sorted(task.get("requiredCost") or {})
        self.today_material_table.setRowCount(len(resources))

        def val_str(v):
            return "?" if v is None else str(v)

        for row_idx, key in enumerate(resources):
            info = (task.get("resourceInfo") or {}).get(key, {})
            label = info.get("name") or key
            amount = task.get("requiredCost", {}).get(key, 0)
            items = [QTableWidgetItem(label), QTableWidgetItem(val_str(amount))]
            for col_i, col_item in enumerate(items):
                col_item.setFlags(col_item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                if col_i > 0:
                    col_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                self.today_material_table.setItem(row_idx, col_i, col_item)
        self.today_material_table.resizeRowsToContents()
        self.today_material_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)

        # Metadata Card
        account_settings = plan.get("accountSettings") or {}
        wl = account_settings.get("worldLevel", "?")
        cur_resin = "unknown" if account_settings.get("resin") is None else str(account_settings["resin"])
        srv = plan.get("serverRegion", "ASIA")
        state = plan.get("todayState") or {}
        pinned_text = state.get("pinnedCharacterKey") or "Không có"
        if state.get("pinnedCharacterKey"):
            pinned_text += f" ({state.get('pinStatus')})"

        dec_labels = {"STRATEGIC": "Ưu tiên chiến lược", "PINNED": "Theo nhân vật ghim", "FALLBACK": "Phương án tốt nhất"}
        dec_mode = dec_labels.get(plan.get("decisionMode"), plan.get("decisionMode") or "-")

        meta_rows = [
            f"• World Level: <b>{wl}</b>  |  Resin hiện tại: <b>{cur_resin}</b>",
            f"• Server: <b>{srv}</b>",
            f"• Ghim Today: <b>{pinned_text}</b>",
        ]
        if task.get("dependsOn"):
            meta_rows.append(f"• Blockers: {' · '.join(task['dependsOn'])}")
        self.today_meta_info.setText("<br>".join(meta_rows))

        # Alternatives
        self.today_alternatives_list.clear()
        alternatives = plan.get("alternativeTasks") or []
        if alternatives:
            for alt in alternatives:
                item = QListWidgetItem(alt.get('title', alt.get('id', 'task')))
                self.today_alternatives_list.addItem(item)
        else:
            self.today_alternatives_list.addItem(QListWidgetItem("Không có phương án thay thế khả dụng."))

        # Retain plain text in hidden today_context
        lines = [
            f"Hành động đề xuất: {action_text}", f"Chi phí ước tính: {task.get('requiredCost') or {}}", f"Vì sao: {why_summary}",
            f"Khả dụng: {avail_str}", f"Điểm ưu tiên: {task.get('score', 0):.1f}"
        ]
        self.today_context.setPlainText("\n".join(lines))

    def _render_roadmap(self, data):
        tree = self.roadmap_tree
        tree.clear()
        plan = data["roadmap"]
        goals = sorted((plan or {}).get("global", []), key=lambda goal: int(goal.get("rank", 0)))
        if not goals:
            missing_profiles = int((((data.get("today") or {}).get("coverage") or {}).get("missingProfiles")) or 0)
            knowledge_ready = bool((((data.get("today") or {}).get("coverage") or {}).get("buildKnowledgeReady", True)))
            self.roadmap_summary.setText(
                f"Build Knowledge Base chưa đạt release gate. Còn {missing_profiles} nhân vật thiếu profile Basic đã duyệt."
                if missing_profiles or not knowledge_ready else "Không còn bước nâng có giá trị theo build profile hiện tại.")
            self.roadmap_setup_target.setVisible(False)
            self._filter_roadmap()
            return
        self.roadmap_setup_target.setVisible(False)

        status_labels = {
            "ACTIONABLE": "🟢 Có thể làm",
            "BLOCKED": "Đang chờ",
            "READY": "✨ Đã đạt",
            "COMPLETE": "✔ Hoàn tất",
        }
        characters = {goal.get("character", {}).get("key") for goal in goals}
        self.roadmap_summary.setText(
            f"{len(goals)} mục tiêu · {len(characters)} nhân vật · Sắp xếp theo ưu tiên toàn account")

        for goal in goals:
            character = goal.get("character") or {}
            character_key = character.get("key") or "-"
            group = goal.get("planningGroup", "NORMAL")
            group_label = {"PERSONAL": "Muốn build", "THEATER": "Nhà Hát"}.get(group)
            character_label = f"{group_label} · {character_key}" if group_label else character_key

            milestone = goal.get("nextMilestone") or {}
            final_target = goal.get("strategicTarget") or {}
            if final_target.get("value") is None:
                final_target = goal.get("target") or {}
            score = goal.get("score")
            rank_str = str(goal.get("rank", "-"))

            raw_status = goal.get("status")
            status_text = status_labels.get(raw_status, raw_status or "-")

            row = QTreeWidgetItem([
                f"#{rank_str}",
                character_label + " · " + str(goal.get("title") or goal.get("type") or "mục tiêu"),
                str((goal.get("current") or {}).get("value", "-")),
                str(milestone.get("value", "-")),
                str(final_target.get("value", "-")),
                status_text,
                f"{float(score):.1f}" if score is not None else "-",
            ])
            row.setData(0, Qt.ItemDataRole.UserRole, character_key)
            row.setData(5, Qt.ItemDataRole.UserRole, raw_status)

            # Center text for specific columns
            for col in (0, 2, 3, 4, 5, 6):
                row.setTextAlignment(col, Qt.AlignmentFlag.AlignCenter)

            # Highlight top 3 ranks
            if rank_str in ("1", "2", "3"):
                row.setForeground(0, QColor(COLORS["accent_hover"]))
                font = row.font(0)
                font.setBold(True)
                row.setFont(0, font)

            # Color status
            if raw_status == "ACTIONABLE":
                row.setForeground(5, QColor(COLORS["success"]))
            elif raw_status == "BLOCKED":
                row.setForeground(5, QColor(COLORS["warning"]))
            elif raw_status == "READY":
                row.setForeground(5, QColor(COLORS["secondary"]))
            elif raw_status == "COMPLETE":
                row.setForeground(5, QColor(COLORS["secondary"]))

            chain = goal.get("milestoneChain") or []
            chain_text = " → ".join(str(value) for value in ([chain[0]["from"]] + [step["to"] for step in chain])) if chain else "-"
            row.setToolTip(3, "Chuỗi milestone: " + chain_text)
            row.setToolTip(4, "Mốc progression cuối theo build profile đã duyệt.")
            tree.addTopLevelItem(row)

        self._configure_roadmap_columns(self.roadmap_details_toggle.isChecked())

        self._filter_roadmap()

    def _open_goal_character(self, item, _column=0):
        key = item.data(0, Qt.ItemDataRole.UserRole)
        if not key:
            return
        for index in range(self.character_list.count()):
            if self.character_list.item(index).text() == key:
                self.nav.setCurrentRow(2)
                self.character_list.setCurrentRow(index)
                return

    def _render_characters(self, data):
        self.account_summary.setText(f"{len(data['characters'])} nhân vật trong tài khoản")
        selected = self.character_list.currentItem().text() if self.character_list.currentItem() else None
        self.character_list.clear()

        for row in data["characters"]:
            key = row["key"]
            item = QListWidgetItem(key)
            item.setIcon(QIcon(get_character_pixmap(key, 32)))
            self.character_list.addItem(item)

        keys = [row["key"] for row in data["characters"]]
        self.character_tabs.setVisible(bool(keys))
        self.character_empty.setVisible(not keys)
        for control in (self.character_config_button, self.pin_button, self.character_more_button):
            control.setEnabled(bool(keys))
        self.wants_build_button.setEnabled(bool(keys) and self.build_intent_controller is not None)
        self.edit_rv_button.setEnabled(bool(keys))
        if keys:
            self.character_list.setCurrentRow(keys.index(selected) if selected in keys else 0)
        else:
            self.char_name.setText("Chưa có nhân vật trong snapshot")
            self.character_detail.setPlainText("Chưa có nhân vật trong snapshot hiện tại.")

        self._filter_characters(self.character_search.text())

    def _show_character(self, index):
        if not self._data or index < 0 or index >= len(self._data["characters"]):
            return
        row = self._data["characters"][index]
        char_key = row["key"]
        target = row["target"] or {}
        current_talents = row["talents"]

        # 1. Header Card
        self.char_name.setText(char_key)
        self.char_avatar.setPixmap(get_character_pixmap(char_key, 76))
        profile_rows = row.get("buildProfiles") or []
        self.char_tier_badge.setText("Mức độ liên quan: tự suy luận")
        self.char_preset_badge.setText(f"Build profiles: {len(profile_rows)}")

        pinned_key = ((self._data.get("today") or {}).get("todayState") or {}).get("pinnedCharacterKey")
        is_pinned = (pinned_key == char_key)
        self.char_pin_badge.setText("Đang ghim Today" if is_pinned else "Chưa ghim")
        if is_pinned:
            self.char_pin_badge.setObjectName("badge")
            set_state(self.char_pin_badge, "accent")
        else:
            self.char_pin_badge.setObjectName("badge")
            set_state(self.char_pin_badge, "")

        priority_mode = row.get("priorityOverride", "NORMAL")
        priority_label = {"PRIORITIZED": "Ưu tiên", "DEPRIORITIZED": "Hạ ưu tiên"}.get(priority_mode, "Bình thường")
        self.char_priority_badge.setText(f"Ưu tiên chiến lược: {priority_label}")
        set_state(self.char_priority_badge, "accent" if priority_mode == "PRIORITIZED" else "")
        self.char_priority_badge.show()
        personal_state = (self._data.get("personalPriorities") or {}).get(char_key)
        self.wants_build_button.setText({"WANT_BUILD": "Đang muốn build", "COMPLETE": "Build đã hoàn thành"}.get(personal_state, "Muốn build"))
        self.wants_build_button.setProperty("buildState", personal_state or "NORMAL")
        self.wants_build_button.setEnabled(self.build_intent_controller is not None)
        unknown_rv_slots = sorted(art.get("slot", "?") for art in row.get("artifacts", []) if art.get("rv") is None)
        self.edit_rv_button.setText(f"Điền RV ({len(unknown_rv_slots)})…" if unknown_rv_slots else "Cập nhật RV…")
        self.edit_rv_button.setToolTip(
            "Thiếu RV ở: " + ", ".join(unknown_rv_slots) if unknown_rv_slots
            else "Mở biểu mẫu snapshot để cập nhật RV")
        self.edit_rv_button.setEnabled(bool(self._data.get("characters")) and not self._loading)

        # 2. Level Box
        cur_lvl = row.get("level", 0)
        cur_asc = row.get("ascension", 0)
        self.char_level_val.setText(f"Hiện tại: Lv {cur_lvl} / 100 (Đột phá {cur_asc})")
        pct = min(100, int((cur_lvl / 100) * 100))
        self.char_level_progress.setValue(pct)
        self.char_level_progress.setFormat(f"Lv {cur_lvl}/100")

        # 3. Talents Box
        talent_labels = {"normal": "Đánh thường", "skill": "Kỹ năng (E)", "burst": "Nộ (Q)"}
        t_lines = []
        for k in ("normal", "skill", "burst"):
            c_val = current_talents.get(k, "-")
            t_lines.append(f"• {talent_labels[k]}: <b>{c_val}</b>")
        self.char_talent_val.setText("<br>".join(t_lines))

        # 4. Weapon Box
        weapon = row.get("weapon")
        w_key = weapon.get("key") if weapon else ""
        self.char_weapon_avatar.setPixmap(get_weapon_pixmap(w_key, 48))

        cur_w_str = f"<b>{weapon['key']}</b> Lv {weapon['level']} (R{weapon['refinement']})" if weapon else "Chưa nhận diện"
        self.char_weapon_val.setText(f"Đang trang bị: {cur_w_str}")

        # 5. 5 Artifacts Box
        slot_aliases = {
            "flower of life": "flower", "flower": "flower",
            "plume of death": "plume", "plume": "plume",
            "sands of eon": "sands", "sands": "sands",
            "goblet of eonothem": "goblet", "goblet": "goblet",
            "circlet of logos": "circlet", "circlet": "circlet",
        }
        artifact_by_slot = {
            slot_aliases.get(str(art.get("slot", "")).casefold(), str(art.get("slot", "")).casefold()): art
            for art in row.get("artifacts", [])
        }
        slot_order = ["flower", "plume", "sands", "goblet", "circlet"]
        known_rv = []

        for i, s_key in enumerate(slot_order):
            art = artifact_by_slot.get(s_key)
            if not art:
                self.char_art_set[i].setText("Chưa có đồ")
                self.char_art_main[i].setText("-")
                self.char_art_subs[i].setText("Thiếu dữ liệu")
                self.char_art_rv[i].setText("RV -")
                continue

            self.char_art_set[i].setText(f"{art.get('set', 'Unknown')} +{art.get('level', 0)}")
            self.char_art_main[i].setText(str(art.get("mainStat", "-")))

            sub_texts = [f"• {s.get('key', '?')}: {s.get('value', '?')}" for s in (art.get("substats") or [])]
            self.char_art_subs[i].setText("\n".join(sub_texts) if sub_texts else "Không có substat")

            rv = art.get("rv")
            if rv is not None:
                known_rv.append(float(rv))
                self.char_art_rv[i].setText(f"RV {float(rv):.1f}")
                self.char_art_rv[i].setObjectName("badge")
                set_state(self.char_art_rv[i], "success")
            else:
                self.char_art_rv[i].setText(f"RV ?")
                self.char_art_rv[i].setObjectName("badge")
                set_state(self.char_art_rv[i], "")

        rv_total = sum(known_rv)
        self.char_artifact_summary.setText(f"RV tổng đã biết: {rv_total:.1f} · Đủ RV {len(known_rv)}/5")

        gate_info = f"RV đã biết: <b>{len(known_rv)}/5 slot</b> · Đánh giá theo build profile"
        self.char_artifact_gate.setText(gate_info)

        # 6. Teams & Planner Notes
        teams = row.get("teams", [])
        if teams:
            team_chips = []
            for tm in teams:
                if tm.get("isPrimary"):
                    team_chips.append(f"<span style='color:#f3cb7c; font-weight:bold;'>✦ {tm['name']} [ĐỘI CHÍNH]</span>")
                else:
                    team_chips.append(f"• {tm['name']}")
            self.char_teams_val.setText("  ·  ".join(team_chips))
        else:
            self.char_teams_val.setText("Chưa gán vào đội hình nào.")

        tgt_lines = [f"{item['archetype']} · {item['depth']} · {item['status']}" for item in profile_rows]
        if not tgt_lines:
            tgt_lines.append("Chưa có build profile được duyệt cho nhân vật này.")
        self.char_target_notes.setText("<br>".join(tgt_lines))

        # 7. Update raw text edit for backward-compatibility & inspection
        lines = [row["key"], "", "ACCOUNT SNAPSHOT"]
        lines.append(f"Level {row['level']} / {row['ascension']} ascension")
        lines.append("Talents: " + " · ".join(f"{k}: {current_talents.get(k, '-')}" for k in ("normal", "skill", "burst")))
        lines.append(f"Weapon: {cur_w_str}")
        lines.append("\n5 ARTIFACT ĐANG MẶC · RV")
        for s_name, s_key in [("Hoa", "flower"), ("Lông", "plume"), ("Đồng hồ", "sands"), ("Ly", "goblet"), ("Nón", "circlet")]:
            art = artifact_by_slot.get(s_key)
            if art:
                rv_txt = f"{float(art['rv']):.1f}" if art.get("rv") is not None else "unknown"
                lines.append(f"{s_name}: {art.get('set')} +{art.get('level')} · {art.get('mainStat')} · RV {rv_txt}")
            else:
                lines.append(f"{s_name}: thiếu dữ liệu")
        lines.append(f"RV tổng đã biết: {rv_total:.1f} · đủ RV {len(known_rv)}/5")
        lines.append("\nPLANNER CONFIGURATION")
        lines.append("Build profiles: " + (", ".join(item["archetype"] for item in profile_rows) or "chưa có profile đã duyệt"))
        lines.append("Pin Today: " + ("đang pin" if is_pinned else "không"))
        self.character_detail.setPlainText("\n".join(lines))
