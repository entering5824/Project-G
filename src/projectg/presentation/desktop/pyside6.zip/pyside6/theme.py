"""Native Qt design tokens, independent of application and planner behavior."""
from string import Template
from pathlib import Path
import sys

COLORS = dict(background='#17191c', sidebar='#101214', surface='#1d2024',
              elevated='#272b30', hover='#30353b', border='#363b42', text='#f3f4f5',
              secondary='#b0b7c1', accent='#e5b869', accent_hover='#f3cb7c',
              accent_pressed='#c8963e', success='#6ee7b7', warning='#fcd34d', danger='#fda4af')

# Standard Qt glyphs are bundled with the existing offline assets directory.
_asset_root = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parents[5]))
_glyphs = _asset_root / 'assets' / 'genshin-impact' / 'ui-controls'
_style_tokens = {**COLORS, **{name: (_glyphs / f'{name}.png').as_posix()
                            for name in ('up', 'down', 'check')}}

DESKTOP_STYLE = Template('''
QWidget { background: $background; color: $text; font-family: 'Segoe UI'; font-size: 14px;
 selection-background-color: $accent; selection-color: $background; }
QMainWindow, QDialog { background: $background; }
QLabel { background: transparent; }
QLabel#pageTitle { font-size: 30px; font-weight: 700; }
QLabel#pageSubtitle, QLabel#searchFeedback, QLabel#secondaryText { color: $secondary; font-size: 13px; }
QLabel#section { font-size: 18px; font-weight: 700; }
QLabel#eyebrow { color: $accent; font-size: 12px; font-weight: 600; }
QLabel#headline { color: $text; font-size: 28px; font-weight: 700; }
QLabel#todayAction { color: $secondary; font-size: 14px; }
QFrame#pageHeader { background: transparent; }
QFrame#sidebar { background: $sidebar; border-right: 1px solid $border; }
QLabel#brandGlyph { color: $accent; font-size: 24px; font-weight: 700; }
QLabel#brandTitle { font-size: 15px; font-weight: 700; }
QLabel#brandSubtitle { color: $secondary; font-size: 10px; font-weight: 600; }
QFrame#sidebarDivider { background: $border; border: none; }
QLabel#sidebarFooter { color: $secondary; font-size: 12px; }
QListWidget#navList { background: transparent; border: 1px solid transparent; }
QListWidget#navList::item { padding: 0; margin: 0; border: none; }
QListWidget#navList::item:selected { background: transparent; }
QFrame#sidebar QToolButton { padding-left: 8px; padding-right: 24px; }
QFrame#primary, QFrame#surfaceCard, QFrame#artifactSlot { background: $surface; border: none; border-radius: 12px; }
QFrame#primary { background: $elevated; border-left: 3px solid $accent; }
QFrame#artifactSlot { background: $background; border-radius: 6px; }
QFrame#artifactSlot QLabel { background: transparent; border: none; }
QLabel#badge { background: $surface; color: $secondary; border: none;
 border-radius: 6px; padding: 5px 8px; font-size: 12px; font-weight: 600; }
QLabel#badge[state="accent"] { color: $accent_hover; }
QLabel#badge[state="success"] { color: $success; }
QLabel#badge[state="warning"] { color: $warning; }
QLabel#badge[state="danger"] { color: $danger; }
QLabel#fact { background: transparent; color: $secondary; border: none;
 border-left: 1px solid $border; border-radius: 0; padding: 6px 12px; font-size: 13px; font-weight: 600; }
QLabel#fact[state="success"] { color: $success; }
QLabel#fact[state="warning"] { color: $warning; }
QPushButton, QToolButton { background: $elevated; color: $text; border: 1px solid $border;
 border-radius: 6px; padding: 7px 12px; min-height: 20px; font-weight: 600; }
QPushButton:hover, QToolButton:hover { background: $hover; border-color: #52627a; }
QPushButton:pressed, QToolButton:pressed { background: $background; }
QPushButton:checked, QToolButton:checked { background: $hover; color: $accent_hover; }
QPushButton:disabled, QToolButton:disabled { background: $sidebar; color: $secondary; border-color: $border; }
QPushButton#primaryButton, QToolButton#primaryButton { background: $accent; color: $background; border-color: $accent; font-weight: 700; }
QPushButton#primaryButton:hover, QToolButton#primaryButton:hover { background: $accent_hover; border-color: $accent_hover; }
QPushButton#primaryButton:pressed, QToolButton#primaryButton:pressed { background: $accent_pressed; border-color: $accent_pressed; }
QPushButton#primaryButton:disabled, QToolButton#primaryButton:disabled { background: $elevated; color: $secondary; border-color: $border; }
QToolButton#primaryButton { padding-right: 30px; }
QToolButton#primaryButton::menu-button { border-left: 1px solid #b58a43; width: 22px; }
QPushButton#ghostButton { background: transparent; color: $secondary; border-color: $border; }
QPushButton#ghostButton:hover, QPushButton#ghostButton:checked { color: $accent_hover; background: $elevated; }
QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox { background: $surface; border: 1px solid $border;
 border-radius: 6px; padding: 6px 10px; min-height: 22px; color: $text; }
QLineEdit:disabled, QComboBox:disabled, QSpinBox:disabled, QDoubleSpinBox:disabled { color: $secondary; }
QComboBox::drop-down { border: none; width: 24px; }
QComboBox::down-arrow { image: url("$down"); width: 12px; height: 12px; }
QSpinBox, QDoubleSpinBox { padding-right: 24px; }
QSpinBox::up-button, QDoubleSpinBox::up-button { subcontrol-origin: border; subcontrol-position: top right; width: 22px; }
QSpinBox::down-button, QDoubleSpinBox::down-button { subcontrol-origin: border; subcontrol-position: bottom right; width: 22px; }
QSpinBox::up-arrow, QDoubleSpinBox::up-arrow { image: url("$up"); width: 10px; height: 10px; }
QSpinBox::down-arrow, QDoubleSpinBox::down-arrow { image: url("$down"); width: 10px; height: 10px; }
QComboBox QAbstractItemView { background: $surface; color: $text; border: 1px solid $border;
 selection-background-color: #273449; selection-color: $text; padding: 4px; }
QCheckBox { spacing: 8px; }
QCheckBox::indicator { width: 16px; height: 16px; border: 1px solid #52627a; border-radius: 3px; background: $surface; }
QCheckBox::indicator:checked { image: url("$check"); background: $elevated; border-color: $accent; }
QCheckBox:disabled { color: $secondary; }
QListWidget, QTreeWidget, QTableWidget, QTextEdit { background: $surface; alternate-background-color: #22262b;
 border: 1px solid $border; border-radius: 6px; gridline-color: $border; }
QListWidget::item, QTreeWidget::item { padding: 10px 12px; }
QListWidget::item:hover, QTreeWidget::item:hover, QTableWidget::item:hover { background: $elevated; }
QListWidget::item:selected, QTreeWidget::item:selected, QTableWidget::item:selected { background: #3b3931; color: $text; }
QHeaderView::section { background: $surface; color: $secondary; padding: 12px 10px; border: none;
 border-bottom: 1px solid $border; font-weight: 600; }
QScrollBar:vertical { background: transparent; width: 10px; margin: 2px; }
QScrollBar:horizontal { background: transparent; height: 10px; margin: 2px; }
QScrollBar::handle:vertical { background: #52627a; border-radius: 3px; min-height: 28px; }
QScrollBar::handle:horizontal { background: #52627a; border-radius: 3px; min-width: 28px; }
QScrollBar::handle:hover { background: $secondary; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width: 0; }
QScrollBar::add-page, QScrollBar::sub-page { background: transparent; }
QSplitter::handle { background: $border; }
QSplitter::handle:hover { background: $accent; }
QMenu { background: $surface; color: $text; border: 1px solid $border; border-radius: 6px; padding: 6px; }
QMenu::item { padding: 8px 22px; border-radius: 4px; }
QMenu::item:selected { background: $elevated; color: $accent_hover; }
QMenu::item:disabled { color: $secondary; }
QMenu::separator { height: 1px; background: $border; margin: 6px 4px; }
QTabWidget::pane { border: 1px solid $border; border-radius: 6px; top: -1px; }
QTabBar::tab { background: $surface; color: $secondary; padding: 8px 14px; border-bottom: 2px solid transparent; margin-right: 2px; }
QTabBar::tab:selected { background: $elevated; color: $text; border-bottom-color: $accent; }
QTabBar::tab:hover { color: $text; }
QProgressBar { background: $background; border: 1px solid $border; border-radius: 4px;
 text-align: center; color: $text; font-size: 12px; min-height: 18px; }
QProgressBar::chunk { background: $accent; border-radius: 3px; }
QStatusBar { background: $background; color: $secondary; border-top: 1px solid $border; font-size: 12px; }
QToolTip { background: $elevated; color: $text; border: 1px solid #52627a; padding: 7px; }
QPushButton:focus, QToolButton:focus, QLineEdit:focus, QComboBox:focus,
QSpinBox:focus, QDoubleSpinBox:focus, QListWidget:focus, QTreeWidget:focus,
QTableWidget:focus, QTextEdit:focus { border-color: $accent; }
QCheckBox:focus { color: $accent_hover; }
QTabBar::tab:focus { border-bottom-color: $accent; }
QFrame#feedbackBanner { background: $elevated; border: 1px solid $border; border-radius: 6px; }
QFrame#feedbackBanner[state="error"] { border-color: $danger; }
''').substitute(_style_tokens)


def set_state(widget, state: str) -> None:
    """Re-polish semantic state without duplicating per-widget styling."""
    widget.setProperty('state', state)
    widget.style().unpolish(widget)
    widget.style().polish(widget)
    widget.update()
